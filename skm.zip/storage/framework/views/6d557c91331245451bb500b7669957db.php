<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'SKM Saller - Genuine Car Logos, Monograms & Emblems'); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description', 'India\'s leading online specialist for genuine car logos, chrome emblems, car monograms, and custom badges.'); ?>">
    
    <?php
        $appLogo = \App\Models\Setting::get('site_logo');
        $appFavicon = \App\Models\Setting::get('site_favicon');
        $appName = \App\Models\Setting::get('store_name', 'SKM Saller');
        $appTagline = \App\Models\Setting::get('store_tagline', 'CAR LOGOS & EMBLEMS');
        $appPhone = \App\Models\Setting::get('store_phone', '+91 98765 43210');
        $appMobile = \App\Models\Setting::get('store_mobile', $appPhone);
        $appEmail = \App\Models\Setting::get('store_email', 'info@autologos.in');
        $appAddress = \App\Models\Setting::get('store_address', '123, Auto Street, New Delhi, India - 110001');
        $appAnnouncement = \App\Models\Setting::get('header_announcement_text', \App\Models\Setting::get('announcement_bar_text', 'Free Pan-India Delivery on orders above ₹999 | 100% Genuine Fitment Guarantee'));
        $appWhatsappRaw = \App\Models\Setting::get('whatsapp_support_number', \App\Models\Setting::get('whatsapp_phone', '919876543210'));
        $appWhatsappClean = preg_replace('/[^0-9]/', '', $appWhatsappRaw ?: '919876543210');
        $appFacebook = \App\Models\Setting::get('facebook_url', 'https://facebook.com');
        $appInstagram = \App\Models\Setting::get('instagram_url', 'https://instagram.com');
        $appYoutube = \App\Models\Setting::get('youtube_url', 'https://youtube.com');
        $appGstin = \App\Models\Setting::get('gstin', '07AAAAA0000A1Z5');
    ?>

    <?php if($appFavicon && file_exists(public_path($appFavicon))): ?>
        <link rel="icon" href="<?php echo e(asset($appFavicon)); ?>">
        <link rel="shortcut icon" href="<?php echo e(asset($appFavicon)); ?>">
    <?php else: ?>
        <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('images/dummy-product.svg')); ?>">
    <?php endif; ?>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Montserrat:ital,wght@0,600;0,700;0,800;0,900;1,700;1,900&display=swap" rel="stylesheet">
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <!-- Select2 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    
    <style>
        :root {
            --primary-red: #d90429;
            --primary-red-hover: #ef233c;
            --dark-black: #0b0f19;
            --dark-bg: #0b0f19;
            --dark-surface: #111827;
            --dark-surface-2: #161f30;
            --dark-border: #1e293b;
            --header-black: #0b0f19;
            --card-border: #1e293b;
            --text-dark: #f8fafc;
            --text-muted: #94a3b8;
        }

        /* ========================================================
           SweetAlert2 Professional SaaS Theme (Dark Automotive Style)
           ======================================================== */
        /* Modal Dialog Customization */
        .swal2-popup.swal2-modal {
            font-family: 'Inter', sans-serif !important;
            border-radius: 16px !important;
            padding: 2rem !important;
            background: #111827 !important;
            border: 1px solid #1e293b !important;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.6) !important;
        }
        .swal2-modal .swal2-title {
            font-weight: 700 !important;
            font-size: 1.25rem !important;
            color: #f8fafc !important;
            margin-bottom: 0.5rem !important;
            padding: 0 !important;
        }
        .swal2-modal .swal2-html-container {
            font-size: 0.925rem !important;
            color: #94a3b8 !important;
            line-height: 1.55 !important;
            margin: 0 !important;
        }
        .swal2-modal .swal2-icon {
            margin: 0.5rem auto 1.25rem auto !important;
            transform: scale(0.95);
        }
        .swal2-modal .swal2-actions {
            margin-top: 1.5rem !important;
            gap: 10px !important;
        }
        .btn-swal-confirm {
            background-color: var(--primary-red, #d90429) !important;
            color: #ffffff !important;
            border-radius: 8px !important;
            font-weight: 600 !important;
            font-size: 0.875rem !important;
            padding: 9px 22px !important;
            box-shadow: 0 4px 12px rgba(217, 4, 41, 0.25) !important;
            border: none !important;
            transition: all 0.2s ease !important;
        }
        .btn-swal-confirm:hover {
            background-color: #b90323 !important;
            transform: translateY(-1px) !important;
        }
        .btn-swal-cancel {
            background-color: #1e293b !important;
            color: #cbd5e1 !important;
            border-radius: 8px !important;
            font-weight: 600 !important;
            font-size: 0.875rem !important;
            padding: 9px 22px !important;
            border: 1px solid #334155 !important;
            transition: all 0.2s ease !important;
        }
        .btn-swal-cancel:hover {
            background-color: #334155 !important;
            color: #ffffff !important;
        }

        /* ========================================================
           Floating Toast Notification Customization (Dark Automotive)
           ======================================================== */
        .swal2-container.swal2-top-end,
        .swal2-container.swal2-top-right {
            top: 20px !important;
            right: 20px !important;
            padding: 0 !important;
            pointer-events: none !important;
            background: transparent !important;
            z-index: 99999 !important;
        }
        .swal2-popup.swal2-toast {
            position: relative !important;
            box-sizing: border-box !important;
            display: flex !important;
            flex-direction: row !important;
            align-items: center !important;
            width: auto !important;
            min-width: 320px !important;
            max-width: 480px !important;
            padding: 13px 16px !important;
            background: #111827 !important;
            border-radius: 12px !important;
            border: 1px solid #1e293b !important;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5) !important;
            overflow: hidden !important;
            pointer-events: all !important;
        }

        /* Responsive adjustments for mobile */
        @media (max-width: 576px) {
            .swal2-container.swal2-top-end,
            .swal2-container.swal2-top-right {
                top: 12px !important;
                right: 12px !important;
                left: 12px !important;
            }
            .swal2-popup.swal2-toast {
                min-width: 0 !important;
                width: 100% !important;
                max-width: 100% !important;
            }
        }

        /* Subtle Brand Border Tinting */
        .swal2-popup.swal2-toast.swal2-icon-success {
            border-color: #fecdd3 !important;
            box-shadow: 0 10px 25px -5px rgba(217, 4, 41, 0.12), 0 8px 10px -6px rgba(15, 23, 42, 0.05) !important;
        }
        .swal2-popup.swal2-toast.swal2-icon-error {
            border-color: #fee2e2 !important;
        }
        .swal2-popup.swal2-toast.swal2-icon-warning {
            border-color: #fef3c7 !important;
        }
        .swal2-popup.swal2-toast.swal2-icon-info {
            border-color: #cbd5e1 !important;
        }

        /* Order elements properly in Flexbox */
        .swal2-popup.swal2-toast .swal2-icon {
            order: 1 !important;
            width: 32px !important;
            height: 32px !important;
            min-width: 32px !important;
            max-width: 32px !important;
            margin: 0 12px 0 0 !important;
            padding: 0 !important;
            border-radius: 50% !important;
            border: none !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            position: relative !important;
            flex-shrink: 0 !important;
        }

        /* Hide SweetAlert2's messy internal animated SVG lines and rings */
        .swal2-popup.swal2-toast .swal2-icon * {
            display: none !important;
        }

        /* Pixel-perfect Crisp FontAwesome Icon via ::after */
        .swal2-popup.swal2-toast .swal2-icon::after {
            font-family: 'Font Awesome 6 Free' !important;
            font-weight: 900 !important;
            font-size: 13.5px !important;
            line-height: 1 !important;
            display: inline-block !important;
        }

        /* Success Theme (AutoLogos Signature Red) */
        .swal2-popup.swal2-toast .swal2-icon.swal2-success {
            background-color: #fff1f2 !important;
            border: 1px solid #fecdd3 !important;
        }
        .swal2-popup.swal2-toast .swal2-icon.swal2-success::after {
            content: "\f00c" !important; /* fa-check */
            color: #d90429 !important;
        }

        /* Error Theme */
        .swal2-popup.swal2-toast .swal2-icon.swal2-error {
            background-color: #fef2f2 !important;
            border: 1px solid #fecaca !important;
        }
        .swal2-popup.swal2-toast .swal2-icon.swal2-error::after {
            content: "\f00d" !important; /* fa-xmark */
            color: #dc2626 !important;
        }

        /* Warning Theme */
        .swal2-popup.swal2-toast .swal2-icon.swal2-warning {
            background-color: #fffbeb !important;
            border: 1px solid #fde68a !important;
        }
        .swal2-popup.swal2-toast .swal2-icon.swal2-warning::after {
            content: "\f12a" !important; /* fa-exclamation */
            color: #d97706 !important;
        }

        /* Info Theme (Dark Charcoal) */
        .swal2-popup.swal2-toast .swal2-icon.swal2-info {
            background-color: #0b0f19 !important;
        }
        .swal2-popup.swal2-toast .swal2-icon.swal2-info::after {
            content: "\f129" !important; /* fa-info */
            color: #ffffff !important;
        }

        /* Question Theme */
        .swal2-popup.swal2-toast .swal2-icon.swal2-question {
            background-color: #f8fafc !important;
        }
        .swal2-popup.swal2-toast .swal2-icon.swal2-question::after {
            content: "\3f" !important;
            color: #64748b !important;
        }

        /* Toast Title & Text - 100% Dead Center Vertically */
        .swal2-popup.swal2-toast .swal2-title {
            order: 2 !important;
            flex: 1 1 auto !important;
            margin: 0 !important;
            padding: 0 10px 0 0 !important;
            font-size: 13.5px !important;
            font-weight: 600 !important;
            color: #f8fafc !important;
            line-height: 1.35 !important;
            text-align: left !important;
            display: flex !important;
            align-items: center !important;
            align-self: center !important;
            word-break: break-word !important;
        }
        .swal2-popup.swal2-toast .swal2-html-container {
            display: none !important;
            margin: 0 !important;
            padding: 0 !important;
        }

        /* Toast Close Button - Pinned to the Right Edge and Centered Vertically */
        .swal2-popup.swal2-toast .swal2-close {
            order: 3 !important;
            margin: 0 0 0 auto !important;
            padding: 0 !important;
            width: 24px !important;
            height: 24px !important;
            min-width: 24px !important;
            border-radius: 6px !important;
            color: #94a3b8 !important;
            font-size: 18px !important;
            font-family: Arial, sans-serif !important;
            line-height: 1 !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            align-self: center !important;
            border: none !important;
            background: transparent !important;
            cursor: pointer !important;
            transition: all 0.15s ease !important;
            outline: none !important;
            box-shadow: none !important;
            flex-shrink: 0 !important;
        }
        .swal2-popup.swal2-toast .swal2-close:hover {
            color: #d90429 !important;
            background-color: rgba(217, 4, 41, 0.15) !important;
        }
        .swal2-popup.swal2-toast .swal2-close:focus {
            outline: none !important;
            box-shadow: none !important;
        }

        /* Sleek Bottom Progress Bar (AutoLogos Signature Red) */
        .swal2-popup.swal2-toast .swal2-timer-progress-bar-container {
            position: absolute !important;
            bottom: 0 !important;
            left: 0 !important;
            right: 0 !important;
            width: 100% !important;
            height: 3px !important;
            background: rgba(30, 41, 59, 0.7) !important;
            border-bottom-left-radius: 12px !important;
            border-bottom-right-radius: 12px !important;
            overflow: hidden !important;
            z-index: 5 !important;
        }
        .swal2-popup.swal2-toast .swal2-timer-progress-bar {
            height: 3px !important;
            border-bottom-left-radius: 12px !important;
        }
        .swal2-toast.swal2-icon-success .swal2-timer-progress-bar {
            background: #d90429 !important;
        }
        .swal2-toast.swal2-icon-error .swal2-timer-progress-bar {
            background: #ef4444 !important;
        }
        .swal2-toast.swal2-icon-warning .swal2-timer-progress-bar {
            background: #f59e0b !important;
        }
        .swal2-toast.swal2-icon-info .swal2-timer-progress-bar {
            background: #0b0f19 !important;
        }

        /* ========================================================
           Theme-Matched Pagination (AutoLogos Red & Dark Styling)
           ======================================================== */
        .pagination {
            display: inline-flex !important;
            align-items: center !important;
            gap: 5px !important;
            margin-bottom: 0 !important;
            flex-wrap: wrap !important;
        }
        .pagination .page-item {
            margin: 0 !important;
        }
        .pagination .page-item:first-child .page-link,
        .pagination .page-item:last-child .page-link,
        .pagination .page-item .page-link {
            border-radius: 8px !important;
        }
        .pagination .page-link {
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            min-width: 38px !important;
            height: 38px !important;
            padding: 6px 12px !important;
            font-size: 13.5px !important;
            font-weight: 600 !important;
            color: #e2e8f0 !important;
            background-color: #111827 !important;
            border: 1px solid #1e293b !important;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2) !important;
            transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;
            text-decoration: none !important;
        }
        .pagination .page-link:hover {
            color: #ffffff !important;
            background-color: var(--primary-red, #d90429) !important;
            border-color: var(--primary-red, #d90429) !important;
            transform: translateY(-1px) !important;
            box-shadow: 0 4px 10px rgba(217, 4, 41, 0.25) !important;
            z-index: 2 !important;
        }
        .pagination .page-item.active .page-link {
            color: #ffffff !important;
            background-color: var(--primary-red, #d90429) !important;
            border-color: var(--primary-red, #d90429) !important;
            font-weight: 700 !important;
            box-shadow: 0 4px 12px rgba(217, 4, 41, 0.32) !important;
            transform: translateY(-1px) !important;
            z-index: 3 !important;
        }
        .pagination .page-item.disabled .page-link {
            color: #64748b !important;
            background-color: #0b0f19 !important;
            border-color: #1e293b !important;
            opacity: 0.6 !important;
            cursor: not-allowed !important;
            pointer-events: none !important;
            box-shadow: none !important;
        }
        .pagination .page-link:focus {
            outline: none !important;
            box-shadow: 0 0 0 3px rgba(217, 4, 41, 0.2) !important;
            border-color: var(--primary-red, #d90429) !important;
        }
        nav p.small.text-muted,
        .pagination-wrapper .text-muted {
            font-size: 13.5px !important;
            color: #94a3b8 !important;
            font-weight: 500 !important;
            margin-bottom: 0 !important;
        }
        nav p.small.text-muted span.fw-semibold {
            color: #f8fafc !important;
            font-weight: 700 !important;
        }

        /* ================= SELECT2 CUSTOM STYLING ================= */
        /* Only in-page Select2 trigger containers should fill their parent column */
        .select2.select2-container {
            width: 100% !important;
            font-size: 13px;
        }

        /* Prevent dropdowns attached to body from inheriting 100% width or causing page horizontal scroll */
        body > .select2-container {
            font-size: 13px;
            max-width: 100vw;
        }

        .select2-container--default .select2-selection--single {
            height: 38px;
            border: 1px solid #334155;
            border-radius: 6px;
            background-color: #161f30;
            display: flex;
            align-items: center;
            transition: all 0.2s ease;
        }
        .select2-container--default .select2-selection--single .select2-selection__rendered {
            color: #f8fafc;
            line-height: normal;
            padding-left: 12px;
            padding-right: 28px;
            font-weight: 500;
        }
        .select2-container--default .select2-selection--single .select2-selection__arrow {
            height: 36px;
            right: 8px;
        }
        .select2-container--default .select2-selection--single .select2-selection__arrow b {
            border-color: #94a3b8 transparent transparent transparent;
            border-width: 5px 4px 0 4px;
        }
        .select2-container--default.select2-container--open .select2-selection--single .select2-selection__arrow b {
            border-color: transparent transparent #d90429 transparent;
            border-width: 0 4px 5px 4px;
        }
        .select2-container--default.select2-container--focus .select2-selection--single,
        .select2-container--default.select2-container--open .select2-selection--single {
            border-color: var(--primary-red) !important;
            box-shadow: 0 0 0 3px rgba(217, 4, 41, 0.2);
            outline: none;
        }

        /* Select2 Disabled State (Dark Theme) */
        .select2-container--default.select2-container--disabled .select2-selection--single,
        .select2-container--default.select2-container--disabled .select2-selection--multiple {
            background-color: #0b0f19 !important;
            border: 1px solid #1e293b !important;
            cursor: not-allowed !important;
            opacity: 0.85 !important;
        }
        .select2-container--default.select2-container--disabled .select2-selection--single .select2-selection__rendered,
        .select2-container--default.select2-container--disabled .select2-selection--multiple .select2-selection__rendered {
            color: #94a3b8 !important;
        }
        .select2-container--default.select2-container--disabled .select2-selection--single .select2-selection__placeholder {
            color: #94a3b8 !important;
        }
        .select2-container--default.select2-container--disabled .select2-selection--single .select2-selection__arrow b {
            border-color: #64748b transparent transparent transparent !important;
        }

        /* Small select variant */
        .select2-container-sm .select2-selection--single,
        .select2-container--default.select2-container-sm .select2-selection--single {
            height: 32px !important;
            font-size: 12.5px;
        }
        .select2-container-sm .select2-selection--single .select2-selection__arrow,
        .select2-container--default.select2-container-sm .select2-selection--single .select2-selection__arrow {
            height: 30px !important;
        }

        /* Quick Vehicle Selector (Hero section) Dark Theme Inputs */
        #vehicleQuickSearchForm .select2.select2-container {
            width: 100% !important;
        }
        #vehicleQuickSearchForm .select2-container--default .select2-selection--single {
            background-color: #1e293b !important;
            border: 1px solid #334155 !important;
            border-radius: 6px !important;
            height: 42px !important;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
            transition: all 0.2s ease !important;
        }
        #vehicleQuickSearchForm .select2-container--default .select2-selection--single .select2-selection__rendered {
            color: #ffffff !important;
            line-height: 40px !important;
            padding-left: 14px !important;
            padding-right: 28px !important;
            font-weight: 500 !important;
            font-size: 13px !important;
        }
        #vehicleQuickSearchForm .select2-container--default .select2-selection--single .select2-selection__placeholder {
            color: #94a3b8 !important;
        }
        #vehicleQuickSearchForm .select2-container--default .select2-selection--single .select2-selection__arrow {
            height: 40px !important;
            right: 10px !important;
        }
        #vehicleQuickSearchForm .select2-container--default .select2-selection--single .select2-selection__arrow b {
            border-color: #94a3b8 transparent transparent transparent !important;
            border-width: 5px 4px 0 4px !important;
        }
        #vehicleQuickSearchForm .select2-container--default.select2-container--open .select2-selection--single .select2-selection__arrow b {
            border-color: transparent transparent #ef4444 transparent !important;
            border-width: 0 4px 5px 4px !important;
        }
        #vehicleQuickSearchForm .select2-container--default.select2-container--focus .select2-selection--single,
        #vehicleQuickSearchForm .select2-container--default.select2-container--open .select2-selection--single {
            border-color: #ef4444 !important;
            box-shadow: 0 0 0 2px rgba(239, 68, 68, 0.25) !important;
        }
        #vehicleQuickSearchForm .select2-container--default.select2-container--open .select2-selection--single {
            border-bottom-left-radius: 0 !important;
            border-bottom-right-radius: 0 !important;
        }
        #vehicleQuickSearchForm .select2-container--default.select2-container--disabled .select2-selection--single {
            background-color: #0b0f19 !important;
            border-color: #1e293b !important;
            opacity: 0.85 !important;
            cursor: not-allowed !important;
        }
        #vehicleQuickSearchForm .select2-container--default.select2-container--disabled .select2-selection--single .select2-selection__rendered {
            color: #94a3b8 !important;
        }

        /* Quick Vehicle Selector Dropdown (Dark Theme) */
        .quick-search-dropdown.select2-dropdown {
            background-color: #111827 !important;
            border: 1px solid #ef4444 !important;
            border-top: none !important;
            border-radius: 0 0 8px 8px !important;
            box-shadow: 0 16px 36px rgba(0, 0, 0, 0.65) !important;
            color: #f8fafc !important;
            z-index: 999999 !important;
            overflow: hidden !important;
            font-size: 13px !important;
            box-sizing: border-box !important;
            margin-top: -1px;
        }
        .quick-search-dropdown .select2-search--dropdown {
            background-color: #0b0f19 !important;
            padding: 8px 10px !important;
            border-bottom: 1px solid #1f2937 !important;
        }
        .quick-search-dropdown .select2-search--dropdown .select2-search__field {
            background-color: #1f2937 !important;
            border: 1px solid #374151 !important;
            border-radius: 6px !important;
            color: #ffffff !important;
            padding: 7px 12px 7px 32px !important;
            font-size: 13px !important;
            outline: none !important;
            width: 100% !important;
            box-sizing: border-box !important;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%2394a3b8' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='11' cy='11' r='8'/%3E%3Cline x1='21' y1='21' x2='16.65' y2='16.65'/%3E%3C/svg%3E");
            background-position: 10px center !important;
            background-repeat: no-repeat !important;
            background-size: 14px 14px !important;
            transition: all 0.2s ease;
        }
        .quick-search-dropdown .select2-search--dropdown .select2-search__field::placeholder {
            color: #64748b !important;
            font-size: 12.5px;
        }
        .quick-search-dropdown .select2-search--dropdown .select2-search__field:focus {
            border-color: #ef4444 !important;
            box-shadow: 0 0 0 2px rgba(239, 68, 68, 0.25) !important;
            background-color: #111827 !important;
        }

        /* Sleek Dark Scrollbar for Quick Search Dropdown */
        .quick-search-dropdown .select2-results__options {
            max-height: 230px !important;
            overflow-y: auto !important;
            padding: 6px !important;
            scrollbar-width: thin;
            scrollbar-color: #374151 #111827;
        }
        .quick-search-dropdown .select2-results__options::-webkit-scrollbar {
            width: 6px;
        }
        .quick-search-dropdown .select2-results__options::-webkit-scrollbar-track {
            background: #111827;
        }
        .quick-search-dropdown .select2-results__options::-webkit-scrollbar-thumb {
            background: #374151;
            border-radius: 4px;
        }
        .quick-search-dropdown .select2-results__options::-webkit-scrollbar-thumb:hover {
            background: #4b5563;
        }

        /* Items inside Quick Search Dropdown */
        .quick-search-dropdown .select2-results__option {
            padding: 8px 12px !important;
            font-size: 13px !important;
            color: #e2e8f0 !important;
            border-radius: 5px !important;
            margin-bottom: 2px !important;
            cursor: pointer !important;
            transition: all 0.15s ease !important;
        }
        .quick-search-dropdown .select2-results__option--highlighted[aria-selected] {
            background-color: #d90429 !important;
            color: #ffffff !important;
            font-weight: 600 !important;
        }
        .quick-search-dropdown .select2-results__option[aria-selected="true"] {
            background-color: rgba(217, 4, 41, 0.2) !important;
            color: #fca5a5 !important;
            font-weight: 600 !important;
        }
        .quick-search-dropdown .select2-results__option--highlighted[aria-selected="true"] {
            background-color: #d90429 !important;
            color: #ffffff !important;
            font-weight: 700 !important;
        }

        /* Hide empty placeholder item from the dropdown list */
        .select2-container--default .select2-results__option[aria-disabled="true"],
        .quick-search-dropdown .select2-results__option:first-child[aria-selected="true"][id$="-"] {
            display: none !important;
        }

        /* Standard Dropdowns (Shop filters, sorting, account) - Dark Automotive */
        .select2-dropdown-light.select2-dropdown,
        .select2-dropdown {
            background-color: #111827 !important;
            border: 1px solid #334155 !important;
            border-radius: 8px !important;
            box-shadow: 0 16px 36px rgba(0, 0, 0, 0.65) !important;
            z-index: 999999 !important;
            overflow: hidden !important;
            font-size: 13px !important;
            box-sizing: border-box !important;
            color: #f8fafc !important;
        }
        .select2-dropdown-light .select2-search--dropdown,
        .select2-dropdown .select2-search--dropdown {
            padding: 8px !important;
            background: #0b0f19 !important;
            border-bottom: 1px solid #1e293b !important;
        }
        .select2-dropdown-light .select2-search--dropdown .select2-search__field,
        .select2-dropdown .select2-search--dropdown .select2-search__field {
            background-color: #1e293b !important;
            border: 1px solid #374151 !important;
            border-radius: 6px !important;
            color: #ffffff !important;
            padding: 6px 10px !important;
            font-size: 12.5px !important;
            outline: none !important;
            width: 100% !important;
            box-sizing: border-box !important;
        }
        .select2-dropdown-light .select2-search--dropdown .select2-search__field:focus,
        .select2-dropdown .select2-search--dropdown .select2-search__field:focus {
            border-color: var(--primary-red) !important;
            box-shadow: 0 0 0 2px rgba(217, 4, 41, 0.25) !important;
        }
        .select2-dropdown-light .select2-results__options,
        .select2-dropdown .select2-results__options {
            max-height: 220px !important;
            overflow-y: auto !important;
            padding: 4px !important;
            scrollbar-width: thin;
            scrollbar-color: #374151 #111827;
        }
        .select2-dropdown-light .select2-results__option,
        .select2-dropdown .select2-results__option {
            padding: 7px 12px !important;
            font-size: 13px !important;
            color: #e2e8f0 !important;
            border-radius: 5px !important;
            margin-bottom: 2px !important;
        }
        .select2-dropdown-light .select2-results__option--highlighted[aria-selected],
        .select2-dropdown .select2-results__option--highlighted[aria-selected] {
            background-color: var(--primary-red) !important;
            color: #ffffff !important;
            font-weight: 600 !important;
        }
        .select2-dropdown-light .select2-results__option[aria-selected="true"],
        .select2-dropdown .select2-results__option[aria-selected="true"] {
            background-color: rgba(217, 4, 41, 0.2) !important;
            color: #fca5a5 !important;
            font-weight: 700 !important;
        }

        html, body {
            overflow-x: hidden;
            max-width: 100%;
        }

        body {
            font-family: 'Inter', sans-serif;
            color: #e2e8f0;
            background-color: #0b0f19;
        }

        .brand-font {
            font-family: 'Montserrat', sans-serif;
        }

        /* Top Bar */
        .top-bar {
            position: relative;
            z-index: 1050;
            background-color: #0b0f19;
            color: #cbd5e1;
            font-size: 13px;
            padding: 7px 0;
            border-bottom: 1px solid #1e293b;
        }
        .top-bar a {
            color: #cbd5e1;
            text-decoration: none;
            transition: color 0.2s ease;
        }
        .top-bar a:hover {
            color: #ffffff;
        }
        .top-bar .dropdown {
            position: relative;
            z-index: 1060;
        }
        .top-bar .dropdown-menu {
            z-index: 1070 !important;
            margin-top: 8px !important;
            border: 1px solid #334155 !important;
            box-shadow: 0 16px 36px rgba(0, 0, 0, 0.8) !important;
        }

        /* Smart Scroll-Up Sticky Header */
        .sticky-header-container {
            position: relative;
            width: 100%;
            z-index: 1000;
            transition: min-height 0.2s ease;
        }
        .sticky-header-inner {
            width: 100%;
            will-change: transform;
            transition: transform 0.35s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.3s ease;
        }
        /* Sticky mode engaged */
        .sticky-header-container.is-sticky {
            z-index: 1030;
        }
        .sticky-header-container.is-sticky .sticky-header-inner {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1030;
            box-shadow: 0 12px 32px rgba(0, 0, 0, 0.75);
            background: rgba(11, 15, 25, 0.98);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
        }
        /* Sticky compact padding */
        .sticky-header-container.is-sticky .main-header {
            padding: 10px 0;
        }
        /* Scroll Down: slide up out of view */
        .sticky-header-container.is-sticky.header-hidden .sticky-header-inner {
            transform: translateY(-100%);
            box-shadow: none;
            pointer-events: none;
        }
        /* Scroll Up: slide down smoothly into view */
        .sticky-header-container.is-sticky.header-visible .sticky-header-inner {
            transform: translateY(0);
            pointer-events: auto;
        }

        /* Hero Carousel Slider Controls */
        .hero-carousel-btn {
            width: 52px;
            opacity: 0;
            transition: opacity 0.25s ease;
            z-index: 6;
        }
        #heroBannerCarousel:hover .hero-carousel-btn {
            opacity: 1;
        }
        .hero-carousel-btn:hover span {
            background: #d90429 !important;
            border-color: #ef233c !important;
            transform: scale(1.08);
            transition: all 0.2s ease;
        }
        #heroBannerCarousel .carousel-indicators button.active {
            background-color: #d90429 !important;
            width: 38px !important;
        }

        /* Main Header */
        .main-header {
            background: #0b0f19;
            padding: 16px 0;
            border-bottom: 1px solid #1e293b;
            transition: padding 0.3s ease;
        }
        .logo-text {
            font-size: 26px;
            font-weight: 900;
            letter-spacing: -0.5px;
            color: #ffffff;
            text-transform: uppercase;
            line-height: 1;
        }
        .logo-text span {
            color: var(--primary-red);
        }
        .logo-subtext {
            font-size: 9px;
            letter-spacing: 2.5px;
            color: #94a3b8;
            font-weight: 700;
            text-transform: uppercase;
        }

        /* Search Bar */
        .header-search-form {
            display: flex;
            border: 2px solid #1e293b;
            border-radius: 6px;
            overflow: hidden;
            background: #111827;
            transition: border-color 0.2s;
        }
        .header-search-form:focus-within {
            border-color: var(--primary-red);
        }
        .search-category-select {
            border: none;
            border-right: 1px solid #1e293b;
            background: #161f30;
            padding: 10px 14px;
            font-size: 13px;
            font-weight: 500;
            color: #cbd5e1;
            outline: none;
            cursor: pointer;
            max-width: 150px;
        }
        .search-category-select option {
            background: #111827;
            color: #f8fafc;
        }
        .header-search-input {
            border: none;
            padding: 10px 16px;
            font-size: 14px;
            width: 100%;
            outline: none;
            background: #111827;
            color: #ffffff;
        }
        .header-search-input::placeholder {
            color: #64748b;
        }
        .header-search-btn {
            background: var(--primary-red);
            color: #ffffff;
            border: none;
            padding: 0 24px;
            font-size: 16px;
            transition: background 0.2s;
        }
        .header-search-btn:hover {
            background: var(--primary-red-hover);
        }

        /* Nav Header */
        .nav-header {
            background: var(--dark-black);
            border-bottom: 2px solid var(--primary-red);
        }
        .category-trigger-btn {
            background: var(--primary-red);
            color: #ffffff;
            font-weight: 700;
            font-size: 14px;
            letter-spacing: 0.5px;
            padding: 14px 20px;
            border: none;
            display: flex;
            align-items: center;
            gap: 10px;
            width: 100%;
            cursor: pointer;
            transition: background 0.2s;
            text-transform: uppercase;
        }
        .category-trigger-btn:hover {
            background: var(--primary-red-hover);
        }
        .main-nav {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: nowrap;
            width: 100%;
        }
        .main-nav .nav-item {
            flex-shrink: 0;
            white-space: nowrap;
        }
        .main-nav .nav-link {
            color: #ffffff;
            font-weight: 600;
            font-size: 12.5px;
            text-transform: uppercase;
            padding: 13px 8px !important;
            letter-spacing: 0.2px;
            transition: color 0.2s;
            position: relative;
            white-space: nowrap;
            display: inline-flex;
            align-items: center;
        }
        @media (min-width: 1200px) {
            .main-nav .nav-link {
                font-size: 13px;
                padding: 13px 11px !important;
                letter-spacing: 0.3px;
            }
        }
        @media (min-width: 1400px) {
            .main-nav .nav-link {
                padding: 13px 14px !important;
            }
        }
        .main-nav .nav-link:hover, .main-nav .nav-link.active {
            color: var(--primary-red);
        }

        /* Left Category & Vehicle Menu */
        .sidebar-category-card {
            background: #111827;
            border: 1px solid #1e293b;
            border-top: none;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.2);
        }
        .sidebar-category-card .cat-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 11px 16px;
            color: #cbd5e1;
            font-size: 13px;
            font-weight: 600;
            border-bottom: 1px solid #1e293b;
            text-decoration: none;
            transition: all 0.2s ease;
        }
        .sidebar-category-card .cat-item:hover {
            background-color: #161f30;
            color: var(--primary-red);
            padding-left: 20px;
        }
        .sidebar-category-card .cat-item i.cat-icon {
            width: 24px;
            color: #94a3b8;
            font-size: 14px;
            margin-right: 8px;
        }
        .sidebar-category-card .cat-item:hover i.cat-icon {
            color: var(--primary-red);
        }

        /* Vehicle Mega Menu Styles - Dark Automotive Theme */
        .vehicle-mega-menu-wrapper {
            position: relative;
        }
        .vehicle-mega-menu {
            background: #111827 !important;
            border: 1px solid #1e293b !important;
        }
        .vehicle-menu-list {
            position: relative;
        }
        .vehicle-menu-item {
            position: static;
            border-bottom: 1px solid #1e293b !important;
        }
        @media (min-width: 992px) {
            .vehicle-menu-item {
                position: relative;
            }
        }
        .vehicle-menu-link {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 14px;
            color: #e2e8f0 !important;
            text-decoration: none;
            transition: all 0.15s ease;
        }
        .vehicle-menu-link .brand-name {
            color: #f8fafc !important;
            transition: color 0.15s ease;
        }
        .vehicle-menu-link:hover,
        .vehicle-menu-item:hover > .vehicle-menu-link {
            background-color: #161f30 !important;
            color: var(--primary-red) !important;
            padding-left: 18px;
        }
        .vehicle-menu-link:hover .brand-name,
        .vehicle-menu-item:hover > .vehicle-menu-link .brand-name {
            color: var(--primary-red) !important;
        }
        .vehicle-menu-link:hover .arrow-icon,
        .vehicle-menu-item:hover > .vehicle-menu-link .arrow-icon {
            color: var(--primary-red) !important;
            transform: translateX(2px);
        }
        .vehicle-flyout-pane {
            display: none;
            position: absolute;
            left: 100%;
            top: 0;
            width: 580px;
            min-height: 100%;
            max-height: 480px;
            overflow-y: auto;
            background: #111827 !important;
            border: 1px solid #1e293b !important;
            border-left: 3px solid var(--primary-red) !important;
            border-radius: 0 10px 10px 10px;
            padding: 16px;
            z-index: 99999 !important;
            box-shadow: 0 20px 45px rgba(0, 0, 0, 0.65) !important;
        }
        /* Invisible hover bridge to prevent mouse leaving flyout */
        .vehicle-flyout-pane::before {
            content: '';
            position: absolute;
            top: 0;
            left: -15px;
            width: 15px;
            height: 100%;
            background: transparent;
        }
        /* Custom scrollbar for flyout */
        .vehicle-flyout-pane::-webkit-scrollbar {
            width: 6px;
        }
        .vehicle-flyout-pane::-webkit-scrollbar-track {
            background: #0b0f19 !important;
            border-radius: 4px;
        }
        .vehicle-flyout-pane::-webkit-scrollbar-thumb {
            background: #334155 !important;
            border-radius: 4px;
        }
        .vehicle-flyout-pane::-webkit-scrollbar-thumb:hover {
            background: #475569 !important;
        }
        .vehicle-menu-item:hover > .vehicle-flyout-pane {
            display: block;
        }
        /* Smart upward positioning for bottom half items */
        .vehicle-menu-item:nth-child(n+6) > .vehicle-flyout-pane,
        #moreVehicleBrands .vehicle-menu-item > .vehicle-flyout-pane {
            top: auto;
            bottom: -1px;
            border-radius: 10px 10px 10px 0;
        }
        #moreVehicleBrands.show {
            overflow: visible !important;
        }
        .flyout-car-box {
            background: #161f30 !important;
            border: 1px solid #1e293b !important;
            transition: all 0.15s ease;
        }
        .flyout-car-box:hover {
            border-color: #334155 !important;
            background: #1e293b !important;
            box-shadow: 0 4px 10px rgba(0,0,0,0.3) !important;
        }
        .flyout-car-box a.fw-bold {
            color: #f8fafc !important;
        }
        .flyout-car-box a.fw-bold:hover {
            color: var(--primary-red) !important;
        }
        .flyout-variant-pill {
            display: inline-block;
            background: #0b0f19 !important;
            border: 1px solid #334155 !important;
            color: #cbd5e1 !important;
            font-size: 11px;
            font-weight: 600;
            padding: 2px 7px;
            border-radius: 4px;
            text-decoration: none;
            transition: all 0.15s ease;
        }
        .flyout-variant-pill:hover {
            background: var(--primary-red) !important;
            color: #ffffff !important;
            border-color: var(--primary-red) !important;
            transform: translateY(-1px);
        }
        .hover-red:hover {
            color: var(--primary-red) !important;
        }

        /* Product Cards - Dark Theme */
        .product-card {
            background: #111827;
            border: 1px solid #1e293b;
            border-radius: 8px;
            overflow: hidden;
            transition: transform 0.2s, box-shadow 0.2s, border-color 0.2s;
            position: relative;
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        .product-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.45);
            border-color: #334155;
        }
        .product-card .img-wrapper {
            position: relative;
            background: radial-gradient(circle at center, #1e293b 0%, #111827 100%);
            padding: 16px;
            text-align: center;
            height: 180px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            border-bottom: 1px solid #1e293b;
        }
        .product-card .img-wrapper a {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            height: 100%;
            text-decoration: none;
        }
        .product-card .img-wrapper img {
            max-height: 140px;
            max-width: 100%;
            width: auto;
            height: auto;
            object-fit: contain;
            transition: transform 0.3s;
        }
        .product-card:hover .img-wrapper img {
            transform: scale(1.05);
        }
        .product-card .card-body {
            padding: 14px;
            display: flex;
            flex-direction: column;
            flex-grow: 1;
            background: #111827;
        }
        .product-card .product-title {
            font-size: 14px;
            font-weight: 700;
            color: #f8fafc;
            margin-bottom: 4px;
            line-height: 1.3;
            text-decoration: none;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            min-height: 36px;
        }
        .product-card .product-title:hover {
            color: var(--primary-red);
        }
        .product-card .product-subtitle {
            font-size: 12px;
            color: #94a3b8;
            margin-bottom: 8px;
        }
        .product-card .price-tag {
            font-size: 18px;
            font-weight: 800;
            color: #ffffff;
        }
        .product-card .old-price {
            font-size: 13px;
            color: #64748b;
            text-decoration: line-through;
            margin-left: 6px;
        }

        /* Buttons */
        .btn-theme-red {
            background: var(--primary-red);
            color: #ffffff;
            font-weight: 700;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            transition: all 0.2s;
            text-transform: uppercase;
            font-size: 13px;
        }
        .btn-theme-red:hover {
            background: var(--primary-red-hover);
            color: #ffffff;
        }

        /* Footer */
        .site-footer {
            background: #0b0f19;
            color: #94a3b8;
            padding-top: 50px;
            border-top: 3px solid var(--primary-red);
            font-size: 13px;
        }
        .site-footer h5 {
            color: #ffffff;
            font-size: 15px;
            font-weight: 700;
            margin-bottom: 20px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .site-footer a {
            color: #94a3b8;
            text-decoration: none;
            transition: color 0.2s;
            display: block;
            margin-bottom: 8px;
        }
        .site-footer a:hover {
            color: #ffffff;
            padding-left: 4px;
        }
        .footer-bottom {
            background: #060911;
            padding: 18px 0;
            border-top: 1px solid #1e293b;
            font-size: 12px;
        }

        /* Autocomplete dropdown */
        #searchSuggestionsBox {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: #111827;
            border: 1px solid #334155;
            box-shadow: 0 16px 36px rgba(0,0,0,0.65);
            border-radius: 0 0 8px 8px;
            z-index: 100000;
            max-height: 400px;
            overflow-y: auto;
            display: none;
        }
        .search-item-row {
            display: flex;
            align-items: center;
            padding: 10px 14px;
            border-bottom: 1px solid #1e293b;
            text-decoration: none;
            color: #e2e8f0;
            transition: background 0.2s;
        }
        .search-item-row:hover {
            background: #161f30;
            color: #ffffff;
        }
        .search-item-row img {
            width: 40px;
            height: 40px;
            object-fit: contain;
            margin-right: 12px;
            background: #1e293b;
            border-radius: 6px;
            padding: 4px;
        }

        /* WhatsApp floating badge */
        .whatsapp-float {
            position: fixed;
            bottom: 25px;
            right: 25px;
            background: #25d366;
            color: #ffffff;
            width: 55px;
            height: 55px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 30px;
            box-shadow: 0 6px 16px rgba(37, 211, 102, 0.4);
            z-index: 999;
            text-decoration: none;
            transition: transform 0.2s;
        }
        .whatsapp-float:hover {
            transform: scale(1.1);
            color: #ffffff;
        }

        /* ========================================================
           COMPREHENSIVE GLOBAL DARK AUTOMOTIVE DESIGN SYSTEM
           ======================================================== */
        /* Cards & Containers */
        .card {
            background-color: #111827;
            border-color: #1e293b;
            color: #e2e8f0;
        }
        .card-header {
            background-color: #161f30;
            border-bottom-color: #1e293b;
            color: #f8fafc;
        }
        .card-footer {
            background-color: #0b0f19;
            border-top-color: #1e293b;
            color: #cbd5e1;
        }
        .main-header .text-dark {
            color: #f8fafc !important;
        }
        .main-header .text-dark:hover {
            color: var(--primary-red) !important;
        }

        /* Scoped Dark overrides for Bootstrap Utility Classes */
        body .bg-white {
            background-color: #111827 !important;
            color: #e2e8f0;
        }
        body .bg-light {
            background-color: #090d16 !important;
            color: #cbd5e1;
        }
        body .bg-light-subtle {
            background-color: #161f30 !important;
            color: #e2e8f0;
        }
        body .border,
        body .border-top,
        body .border-bottom,
        body .border-end,
        body .border-start {
            border-color: #1e293b !important;
        }
        body .text-dark {
            color: #f8fafc !important;
        }
        body .text-muted {
            color: #94a3b8 !important;
        }
        body .text-secondary {
            color: #94a3b8 !important;
        }

        /* Breadcrumbs */
        .breadcrumb-item a {
            color: #94a3b8 !important;
        }
        .breadcrumb-item a:hover {
            color: var(--primary-red) !important;
        }
        .breadcrumb-item.active {
            color: #f8fafc !important;
        }
        .breadcrumb-item + .breadcrumb-item::before {
            color: #64748b !important;
        }

        /* Tables */
        .table {
            color: #e2e8f0 !important;
            border-color: #1e293b !important;
        }
        .table > :not(caption) > * > * {
            background-color: transparent !important;
            border-bottom-color: #1e293b !important;
            color: #e2e8f0 !important;
        }
        .table-light, thead.table-light, tr.table-light, th.table-light {
            background-color: #161f30 !important;
            color: #cbd5e1 !important;
            border-color: #1e293b !important;
        }
        .table-striped > tbody > tr:nth-of-type(odd) > * {
            background-color: rgba(255, 255, 255, 0.02) !important;
            color: #e2e8f0 !important;
        }
        .table-hover > tbody > tr:hover > * {
            background-color: #161f30 !important;
            color: #ffffff !important;
        }

        /* Forms, Inputs & Selects */
        .form-control, .form-select {
            background-color: #161f30 !important;
            border: 1px solid #334155 !important;
            color: #f8fafc !important;
        }
        .form-control::placeholder {
            color: #64748b !important;
        }
        .form-control:focus, .form-select:focus {
            background-color: #111827 !important;
            border-color: var(--primary-red) !important;
            color: #ffffff !important;
            box-shadow: 0 0 0 3px rgba(217, 4, 41, 0.25) !important;
        }
        .form-control:disabled, .form-select:disabled {
            background-color: #0b0f19 !important;
            border-color: #1e293b !important;
            color: #94a3b8 !important;
            opacity: 0.85 !important;
            cursor: not-allowed !important;
        }
        .input-group-text {
            background-color: #1e293b !important;
            border: 1px solid #334155 !important;
            color: #cbd5e1 !important;
        }
        .form-check-input {
            background-color: #161f30;
            border-color: #475569;
        }
        .form-check-input:checked {
            background-color: var(--primary-red);
            border-color: var(--primary-red);
        }

        /* Badges & Pills */
        .badge.bg-light {
            background-color: #1e293b !important;
            color: #cbd5e1 !important;
            border: 1px solid #334155 !important;
        }
        .badge.bg-secondary {
            background-color: #334155 !important;
            color: #f8fafc !important;
        }
        .badge.bg-secondary-subtle {
            background-color: #1e293b !important;
            color: #cbd5e1 !important;
        }
        .badge.bg-danger-subtle {
            background-color: rgba(217, 4, 41, 0.18) !important;
            color: #fca5a5 !important;
            border: 1px solid rgba(217, 4, 41, 0.3) !important;
        }

        /* Dropdowns & Menus */
        .dropdown-menu {
            background-color: #111827 !important;
            border: 1px solid #1e293b !important;
            box-shadow: 0 16px 36px rgba(0, 0, 0, 0.65) !important;
        }
        .dropdown-item {
            color: #e2e8f0 !important;
            transition: all 0.15s ease;
        }
        .dropdown-item:hover, .dropdown-item:focus {
            background-color: #161f30 !important;
            color: #ffffff !important;
        }
        .dropdown-divider {
            border-top: 1px solid #1e293b !important;
        }

        /* Modals & Offcanvas */
        .modal-content {
            background-color: #111827 !important;
            border: 1px solid #1e293b !important;
            color: #f8fafc !important;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7) !important;
        }
        .modal-header, .modal-footer {
            border-color: #1e293b !important;
        }
        .offcanvas {
            background-color: #0b0f19 !important;
            color: #e2e8f0 !important;
        }
        .offcanvas-header {
            background-color: #090d16 !important;
            border-bottom: 1px solid #1e293b !important;
        }
        .offcanvas .accordion-item {
            background-color: #111827 !important;
            border-color: #1e293b !important;
        }
        .offcanvas .accordion-button {
            background-color: #111827 !important;
            color: #f8fafc !important;
            border-color: #1e293b !important;
        }
        .offcanvas .accordion-button:not(.collapsed) {
            background-color: #161f30 !important;
            color: var(--primary-red) !important;
        }
        .offcanvas .accordion-button::after {
            filter: invert(1) brightness(0.8);
        }
        .offcanvas .accordion-body {
            background-color: #0b0f19 !important;
        }
        .offcanvas .list-group-item {
            background-color: #111827 !important;
            color: #e2e8f0 !important;
            border-color: #1e293b !important;
        }
        .offcanvas .list-group-item a {
            color: #e2e8f0 !important;
        }

        /* Buttons & Outlines */
        .btn-outline-secondary {
            border-color: #334155 !important;
            color: #cbd5e1 !important;
        }
        .btn-outline-secondary:hover {
            background-color: #1e293b !important;
            color: #ffffff !important;
            border-color: #475569 !important;
        }
        .btn-outline-dark {
            border-color: #475569 !important;
            color: #e2e8f0 !important;
        }
        .btn-outline-dark:hover {
            background-color: var(--primary-red) !important;
            border-color: var(--primary-red) !important;
            color: #ffffff !important;
        }
        .btn-dark {
            background-color: #1e293b !important;
            border-color: #334155 !important;
            color: #ffffff !important;
        }
        .btn-dark:hover {
            background-color: var(--primary-red) !important;
            border-color: var(--primary-red) !important;
            color: #ffffff !important;
        }

        /* Nav Tabs */
        .nav-tabs {
            border-bottom: 2px solid #1e293b !important;
        }
        .nav-tabs .nav-link {
            color: #94a3b8 !important;
            background: transparent !important;
            border: none !important;
        }
        .nav-tabs .nav-link:hover {
            color: #ffffff !important;
        }
        .nav-tabs .nav-link.active {
            color: var(--primary-red) !important;
            border-bottom: 3px solid var(--primary-red) !important;
        }

        /* Alerts */
        .alert-light, .alert-secondary {
            background-color: #161f30 !important;
            border-color: #1e293b !important;
            color: #f8fafc !important;
        }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>

    <!-- 1. TOP INFORMATION BAR -->
    <div class="top-bar">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-4 col-md-5 d-none d-md-block">
                    <span class="me-3"><i class="fa-solid fa-phone text-danger me-1"></i> <?php echo e($appPhone); ?></span>
                    <span><i class="fa-solid fa-envelope text-danger me-1"></i> <?php echo e($appEmail); ?></span>
                </div>
                <div class="col-lg-4 col-md-3 text-center">
                    <span class="fw-semibold"><i class="fa-solid fa-truck-fast text-danger me-1"></i> <?php echo e($appAnnouncement); ?></span>
                </div>
                <div class="col-lg-4 col-md-4 text-end">
                    <a href="<?php echo e(route('order.track.view')); ?>" class="me-3"><i class="fa-solid fa-location-crosshairs text-danger me-1"></i> Track Order</a>
                    <?php if(auth()->guard()->check()): ?>
                        <div class="dropdown d-inline-block">
                            <a href="#" class="dropdown-toggle text-white fw-bold" data-bs-toggle="dropdown">
                                <i class="fa-solid fa-user-circle me-1"></i> <?php echo e(Auth::user()->name); ?>

                            </a>
                            <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                                <?php if(Auth::user()->isAdmin()): ?>
                                    <li><a class="dropdown-item fw-bold text-danger" href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa-solid fa-gauge-high me-2"></i> Admin Panel</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                <?php endif; ?>
                                <li><a class="dropdown-item" href="<?php echo e(route('account.dashboard')); ?>"><i class="fa-solid fa-user me-2"></i> My Account</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('account.orders')); ?>"><i class="fa-solid fa-box-open me-2"></i> My Orders</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('account.addresses')); ?>"><i class="fa-solid fa-address-book me-2"></i> Saved Addresses</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <form action="<?php echo e(route('logout')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="dropdown-item text-danger"><i class="fa-solid fa-right-from-bracket me-2"></i> Logout</button>
                                    </form>
                                </li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>"><i class="fa-solid fa-user text-danger me-1"></i> Login / Register</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- SITE HEADER WRAPPER (Smart Scroll-Up Sticky Header) -->
    <div id="stickyHeaderContainer" class="sticky-header-container">
        <div id="stickyHeaderInner" class="sticky-header-inner">
            <!-- 2. MAIN HEADER -->
            <header class="main-header">
                <div class="container">
                    <div class="row align-items-center">
                        <!-- Mobile Hamburger & Logo -->
                        <div class="col-lg-3 col-md-4 col-7 d-flex align-items-center">
                            <button class="btn btn-outline-dark d-lg-none me-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileMenu">
                                <i class="fa-solid fa-bars"></i>
                            </button>
                            <a href="<?php echo e(route('home')); ?>" class="text-decoration-none">
                                <?php if($appLogo && file_exists(public_path($appLogo))): ?>
                                    <img src="<?php echo e(asset($appLogo)); ?>" alt="<?php echo e($appName); ?>" class="site-header-logo" style="max-height: 80px; max-width: 220px; object-fit: contain;">
                                <?php else: ?>
                                    <div class="d-flex align-items-center">
                                        <div class="me-2">
                                            <i class="fa-solid fa-shield-halved text-danger fs-2"></i>
                                        </div>
                                        <div>
                                            <div class="logo-text brand-font">
                                                <?php
                                                    $words = explode(' ', $appName, 2);
                                                ?>
                                                <?php if(count($words) == 2): ?>
                                                    <?php echo e($words[0]); ?><span><?php echo e($words[1]); ?></span>
                                                <?php else: ?>
                                                    <?php echo e($appName); ?>

                                                <?php endif; ?>
                                            </div>
                                            <div class="logo-subtext"><?php echo e($appTagline); ?></div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </a>
                        </div>

                        <!-- Search Bar with Category Dropdown -->
                        <div class="col-lg-6 col-md-5 d-none d-md-block position-relative">
                            <form action="<?php echo e(route('shop')); ?>" method="GET" class="header-search-form" id="headerSearchForm">
                                <select name="category" class="search-category-select no-select2">
                                    <option value="">All Categories</option>
                                    <?php $__currentLoopData = $globalCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($cat->slug); ?>" <?php echo e(request('category') == $cat->slug ? 'selected' : ''); ?>><?php echo e($cat->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <input type="text" name="q" id="headerSearchInput" class="header-search-input" placeholder="Search for car logos, monograms, emblems..." value="<?php echo e(request('q')); ?>" autocomplete="off">
                                <button type="submit" class="header-search-btn">
                                    <i class="fa-solid fa-magnifying-glass"></i>
                                </button>
                            </form>
                            <div id="searchSuggestionsBox"></div>
                        </div>

                        <!-- Header Actions (Wishlist & Cart) -->
                        <div class="col-lg-3 col-md-3 col-5 text-end">
                            <div class="d-flex align-items-center justify-content-end gap-3">
                                <a href="<?php echo e(route('wishlist.index')); ?>" class="text-decoration-none text-dark position-relative d-flex align-items-center">
                                    <i class="fa-regular fa-heart fs-4 me-1"></i>
                                    <span class="d-none d-lg-inline fw-semibold font-sm">Wishlist</span>
                                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" id="globalWishlistCounter">
                                        <?php echo e($globalWishlistCount); ?>

                                    </span>
                                </a>

                                <a href="<?php echo e(route('cart.index')); ?>" class="text-decoration-none text-dark position-relative d-flex align-items-center ps-2">
                                    <i class="fa-solid fa-cart-shopping fs-4 text-danger me-1"></i>
                                    <span class="d-none d-lg-inline fw-semibold font-sm">Cart</span>
                                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" id="globalCartCounter">
                                        <?php echo e($globalCartCount); ?>

                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Mobile Search Bar -->
                    <div class="row d-md-none mt-2">
                        <div class="col-12">
                            <form action="<?php echo e(route('shop')); ?>" method="GET" class="header-search-form">
                                <input type="text" name="q" class="header-search-input" placeholder="Search logos, emblems..." value="<?php echo e(request('q')); ?>">
                                <button type="submit" class="header-search-btn"><i class="fa-solid fa-magnifying-glass"></i></button>
                            </form>
                        </div>
                    </div>
                </div>
            </header>

            <!-- 3. NAVIGATION BAR -->
            <nav class="nav-header d-none d-lg-block">
                <div class="container">
                    <ul class="nav main-nav mb-0">
                        <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>"><i class="fa-solid fa-house me-1"></i> HOME</a></li>
                        <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('vehicle*') || request()->routeIs('vehicles') ? 'active' : ''); ?>" href="<?php echo e(route('vehicles')); ?>"><i class="fa-solid fa-car-side text-danger me-1"></i> VEHICLES</a></li>
                        <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('shop') && !request('category') && !request('sort') && !request('placement') && !request('type') && !request('new_arrivals') && !request('brand') && !request('model') ? 'active' : ''); ?>" href="<?php echo e(route('shop')); ?>">ALL PRODUCTS</a></li>

                        
                        <?php if(isset($headerCategories) && $headerCategories->isNotEmpty()): ?>
                            <?php $__currentLoopData = $headerCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $navCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $isCatActive = request('category') == $navCat->slug
                                        || ($navCat->slug == 'new-arrivals' && (request('category') == 'new-arrivals' || request('new_arrivals') == '1'))
                                        || ($navCat->slug == 'front-logo' && (request('category') == 'front-logo' || request('placement') == 'Front' || request('placement') == 'Front Grille'))
                                        || ($navCat->slug == 'rear-logo' && (request('category') == 'rear-logo' || request('placement') == 'Rear' || request('placement') == 'Rear Trunk'))
                                        || ($navCat->slug == 'bonnet-tailgate-letters' && (request('category') == 'bonnet-tailgate-letters' || request('placement') == 'Bonnet' || request('placement') == 'Bonnet / Boot'))
                                        || ($navCat->slug == 'kit-full-monogram' && (request('category') == 'kit-full-monogram' || request('placement') == 'Kit' || request('placement') == 'Full Exterior Kit'))
                                        || ($navCat->slug == 'single-name-badge' && (request('category') == 'single-name-badge' || request('type') == 'badge'));
                                    $isNewArrival = ($navCat->slug == 'new-arrivals' || str_contains(strtolower($navCat->name), 'new arrival'));
                                ?>
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e($isNewArrival ? 'text-warning' : ''); ?> <?php echo e($isCatActive ? 'active' : ''); ?>" href="<?php echo e(route('shop', ['category' => $navCat->slug])); ?>">
                                        <?php if($isNewArrival): ?><i class="fa-solid fa-sparkles me-1"></i><?php endif; ?>
                                        <?php echo e(strtoupper($navCat->name)); ?>

                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <li class="nav-item"><a class="nav-link <?php echo e(request()->routeIs('contact') ? 'active' : ''); ?>" href="<?php echo e(route('contact')); ?>"><i class="fa-solid fa-headset me-1 text-danger"></i> CONTACT US</a></li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>

    <!-- Main Content -->
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <!-- WhatsApp Floating Button -->
    <a href="https://api.whatsapp.com/send?phone=<?php echo e($appWhatsappClean); ?>&text=Hello%20<?php echo e(urlencode($appName)); ?>,%20I%20have%20an%20inquiry%20regarding%20car%20emblems." target="_blank" class="whatsapp-float shadow" title="Chat on WhatsApp">
        <i class="fa-brands fa-whatsapp"></i>
    </a>

    <!-- Mobile Offcanvas Menu -->
    <div class="offcanvas offcanvas-start" tabindex="-1" id="mobileMenu">
        <div class="offcanvas-header bg-dark text-white">
            <?php if($appLogo && file_exists(public_path($appLogo))): ?>
                <img src="<?php echo e(asset($appLogo)); ?>" alt="<?php echo e($appName); ?>" style="max-height: 38px; max-width: 150px; object-fit: contain;">
            <?php else: ?>
                <h5 class="offcanvas-title brand-font"><?php echo e($appName); ?></h5>
            <?php endif; ?>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button>
        </div>
        <div class="offcanvas-body p-0">
            <ul class="list-group list-group-flush">
                <li class="list-group-item"><a href="<?php echo e(route('home')); ?>" class="text-decoration-none text-dark fw-bold"><i class="fa-solid fa-house me-2 text-danger"></i> Home</a></li>
                <li class="list-group-item"><a href="<?php echo e(route('vehicles')); ?>" class="text-decoration-none text-dark fw-bold"><i class="fa-solid fa-car-side me-2 text-danger"></i> Vehicles / Brands</a></li>
                <li class="list-group-item"><a href="<?php echo e(route('shop')); ?>" class="text-decoration-none text-dark fw-bold"><i class="fa-solid fa-border-all me-2 text-danger"></i> All Products</a></li>
                <?php if(isset($headerCategories) && $headerCategories->isNotEmpty()): ?>
                    <?php $__currentLoopData = $headerCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $isMCatActive = request('category') == $mCat->slug;
                            $isMNewArrival = ($mCat->slug == 'new-arrivals' || str_contains(strtolower($mCat->name), 'new arrival'));
                            $mIcon = $mCat->icon ?: ($isMNewArrival ? 'fa-solid fa-sparkles text-warning' : 'fa-solid fa-certificate text-danger');
                        ?>
                        <li class="list-group-item">
                            <a href="<?php echo e(route('shop', ['category' => $mCat->slug])); ?>" class="text-decoration-none text-dark <?php echo e($isMCatActive ? ($isMNewArrival ? 'fw-bold text-warning' : 'fw-bold text-danger') : ''); ?>">
                                <i class="<?php echo e($mIcon); ?> me-2 <?php echo e($isMNewArrival ? 'text-warning' : 'text-danger'); ?>"></i> <?php echo e($mCat->name); ?>

                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <li class="list-group-item"><a href="<?php echo e(route('order.track.view')); ?>" class="text-decoration-none text-dark fw-bold"><i class="fa-solid fa-location-crosshairs me-2 text-danger"></i> Track Order</a></li>
                <li class="list-group-item"><a href="<?php echo e(route('contact')); ?>" class="text-decoration-none text-dark fw-bold"><i class="fa-solid fa-envelope me-2 text-danger"></i> Contact Us</a></li>
            </ul>
        </div>
    </div>

    <!-- 4. SITE FOOTER -->
    <footer class="site-footer mt-5">
        <div class="container pb-5">
            <div class="row g-4">
                <!-- Col 1: About -->
                <div class="col-lg-3 col-md-6">
                    <?php if($appLogo && file_exists(public_path($appLogo))): ?>
                        <div class="mb-3">
                            <img src="<?php echo e(asset($appLogo)); ?>" alt="<?php echo e($appName); ?>" class="site-footer-logo bg-white rounded p-2" style="max-height: 48px; max-width: 190px; object-fit: contain;">
                        </div>
                    <?php else: ?>
                        <div class="logo-text brand-font text-white mb-2">
                            <?php
                                $words = explode(' ', $appName, 2);
                            ?>
                            <?php if(count($words) == 2): ?>
                                <?php echo e($words[0]); ?><span class="text-danger"><?php echo e($words[1]); ?></span>
                            <?php else: ?>
                                <?php echo e($appName); ?>

                            <?php endif; ?>
                        </div>
                        <div class="logo-subtext text-secondary mb-3"><?php echo e($appTagline); ?></div>
                    <?php endif; ?>
                    <p class="text-secondary leading-relaxed">
                        Your one-stop destination for all car logos, monograms, emblems, letters & numbers. 100% genuine and premium quality products for all cars.
                    </p>
                    <div class="d-flex gap-2 mt-3">
                        <?php if($appFacebook): ?><a href="<?php echo e($appFacebook); ?>" target="_blank" class="btn btn-sm btn-outline-secondary text-white rounded-circle"><i class="fa-brands fa-facebook-f"></i></a><?php endif; ?>
                        <?php if($appInstagram): ?><a href="<?php echo e($appInstagram); ?>" target="_blank" class="btn btn-sm btn-outline-secondary text-white rounded-circle"><i class="fa-brands fa-instagram"></i></a><?php endif; ?>
                        <?php if($appYoutube): ?><a href="<?php echo e($appYoutube); ?>" target="_blank" class="btn btn-sm btn-outline-secondary text-white rounded-circle"><i class="fa-brands fa-youtube"></i></a><?php endif; ?>
                        <a href="https://api.whatsapp.com/send?phone=<?php echo e($appWhatsappClean); ?>&text=Hi%20<?php echo e(urlencode($appName)); ?>" target="_blank" class="btn btn-sm btn-outline-secondary text-white rounded-circle"><i class="fa-brands fa-whatsapp"></i></a>
                    </div>
                </div>

                <!-- Col 2: Quick Links -->
                <div class="col-lg-2 col-md-6">
                    <h5>Quick Links</h5>
                    <a href="<?php echo e(route('home')); ?>">Home</a>
                    <a href="<?php echo e(route('vehicles')); ?>">All 18 Brands</a>
                    <a href="<?php echo e(route('shop')); ?>">All Products</a>
                    <?php if(isset($headerCategories) && $headerCategories->isNotEmpty()): ?>
                        <?php $__currentLoopData = $headerCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('shop', ['category' => $fCat->slug])); ?>"><?php echo e($fCat->name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <a href="<?php echo e(route('contact')); ?>">Contact Us</a>
                </div>

                <!-- Col 3: Customer Service -->
                <div class="col-lg-2 col-md-6">
                    <h5>Customer Service</h5>
                    <a href="<?php echo e(route('order.track.view')); ?>">Track Order</a>
                    <a href="<?php echo e(route('page.show', 'shipping-policy')); ?>">Shipping Policy</a>
                    <a href="<?php echo e(route('page.show', 'return-refund-policy')); ?>">Return & Refund</a>
                    <a href="<?php echo e(route('page.show', 'terms-conditions')); ?>">Terms & Conditions</a>
                    <a href="<?php echo e(route('page.show', 'privacy-policy')); ?>">Privacy Policy</a>
                    <a href="<?php echo e(route('page.show', 'faq')); ?>">FAQ</a>
                </div>

                <!-- Col 4: My Account -->
                <div class="col-lg-2 col-md-6">
                    <h5>My Account</h5>
                    <a href="<?php echo e(route('login')); ?>">Login / Register</a>
                    <a href="<?php echo e(route('account.orders')); ?>">My Orders</a>
                    <a href="<?php echo e(route('wishlist.index')); ?>">Wishlist</a>
                    <a href="<?php echo e(route('account.dashboard')); ?>">Account Details</a>
                    <a href="<?php echo e(route('cart.index')); ?>">View Cart</a>
                </div>

                <!-- Col 5: Contact Info -->
                <div class="col-lg-3 col-md-6">
                    <h5>Contact Us</h5>
                    <p class="mb-2"><i class="fa-solid fa-phone text-danger me-2"></i> <?php echo e($appPhone); ?></p>
                    <p class="mb-2"><i class="fa-solid fa-envelope text-danger me-2"></i> <?php echo e($appEmail); ?></p>
                    <p class="mb-2"><i class="fa-solid fa-location-dot text-danger me-2"></i> <?php echo nl2br(e($appAddress)); ?></p>
                    <p class="small text-secondary mt-3">GSTIN: <span class="text-white"><?php echo e($appGstin); ?></span></p>
                </div>
            </div>
        </div>

        <!-- Copyright Bar -->
        <div class="footer-bottom">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-6 text-center text-md-start text-secondary">
                        © <?php echo e(date('Y')); ?> <?php echo e($appName); ?>. All Rights Reserved.
                    </div>
                    <div class="col-md-6 text-center text-md-end text-secondary mt-2 mt-md-0">
                        <span class="me-2">We Accept</span>
                        <span class="badge bg-light text-dark me-1"><i class="fa-brands fa-cc-visa text-primary"></i> VISA</span>
                        <span class="badge bg-light text-dark me-1"><i class="fa-brands fa-cc-mastercard text-danger"></i> Mastercard</span>
                        <span class="badge bg-light text-dark me-1"><i class="fa-solid fa-qrcode text-success"></i> UPI</span>
                        <span class="badge bg-light text-dark"><i class="fa-solid fa-wallet text-info"></i> Paytm</span>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Mobile Offcanvas Menu with Vehicle Hierarchy Accordion -->
    <div class="offcanvas offcanvas-start" tabindex="-1" id="mobileMenu" aria-labelledby="mobileMenuLabel">
        <div class="offcanvas-header bg-dark text-white border-bottom">
            <h5 class="offcanvas-title font-sm fw-bold brand-font" id="mobileMenuLabel">
                <i class="fa-solid fa-car text-danger me-2"></i> SELECT VEHICLE & CATEGORIES
            </h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body p-0">
            <div class="accordion accordion-flush" id="mobileVehicleAccordion">
                <?php $__currentLoopData = $globalBrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingBrand<?php echo e($brand->id); ?>">
                            <button class="accordion-button collapsed py-2 font-sm fw-semibold" type="button" data-bs-toggle="collapse" data-bs-target="#collapseBrand<?php echo e($brand->id); ?>" aria-expanded="false">
                                <span class="d-inline-flex align-items-center justify-content-center rounded me-2 flex-shrink-0" style="width: 26px; height: 26px; background: #161f30; border: 1px solid #1e293b;">
                                    <img src="<?php echo e($brand->logo_url); ?>" alt="<?php echo e($brand->name); ?>" style="max-width: 18px; max-height: 18px; object-fit: contain;">
                                </span>
                                <span><?php echo e($brand->name); ?></span>
                                <span class="badge bg-light text-muted border ms-auto me-2 font-sm" style="font-size: 10px;"><?php echo e($brand->carModels->count()); ?></span>
                            </button>
                        </h2>
                        <div id="collapseBrand<?php echo e($brand->id); ?>" class="accordion-collapse collapse" data-bs-parent="#mobileVehicleAccordion">
                            <div class="accordion-body p-2 bg-light">
                                <a href="<?php echo e(route('vehicle.cars', $brand->slug)); ?>" class="btn btn-outline-danger btn-sm w-100 mb-2 py-1 font-sm fw-bold">
                                    All <?php echo e($brand->name); ?> Models &rarr;
                                </a>
                                <div class="list-group list-group-flush">
                                    <?php $__currentLoopData = $brand->carModels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="list-group-item bg-white rounded border mb-1 p-2">
                                            <div class="d-flex align-items-center justify-content-between mb-1">
                                                <a href="<?php echo e(route('vehicle.variants', [$brand->slug, $car->slug])); ?>" class="fw-bold text-dark text-decoration-none font-sm">
                                                    <i class="fa-solid fa-car text-danger me-1"></i> <?php echo e($car->name); ?>

                                                </a>
                                                <a href="<?php echo e(route('vehicle.variants', [$brand->slug, $car->slug])); ?>" class="text-muted font-sm text-decoration-none" style="font-size: 11px;">
                                                    All &rarr;
                                                </a>
                                            </div>
                                            <?php if($car->variants->isNotEmpty()): ?>
                                                <div class="d-flex flex-wrap gap-1 mt-1">
                                                    <?php $__currentLoopData = $car->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <a href="<?php echo e(route('vehicle.products', [$brand->slug, $car->slug, $variant->slug])); ?>" class="flyout-variant-pill">
                                                            <?php echo e($variant->name); ?>

                                                        </a>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="p-3 border-top bg-light mt-2">
                <a href="<?php echo e(route('vehicles')); ?>" class="btn btn-danger w-100 fw-bold font-sm mb-2">
                    <i class="fa-solid fa-car-side me-1"></i> VIEW ALL VEHICLES
                </a>
                <a href="<?php echo e(route('shop')); ?>" class="btn btn-outline-dark w-100 fw-bold font-sm">
                    <i class="fa-solid fa-boxes-stacked me-1"></i> ALL PRODUCTS & CATEGORIES
                </a>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5 Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Global AJAX Handlers -->
    <script>
        // Setup CSRF token for Fetch / AJAX
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

        // Instant Live Search Suggestions
        const searchInput = document.getElementById('headerSearchInput');
        const suggestionsBox = document.getElementById('searchSuggestionsBox');

        if (searchInput && suggestionsBox) {
            let timeout = null;
            searchInput.addEventListener('input', function() {
                clearTimeout(timeout);
                const val = this.value.trim();
                if (val.length < 2) {
                    suggestionsBox.style.display = 'none';
                    return;
                }

                timeout = setTimeout(() => {
                    const categorySelect = document.querySelector('.search-category-select');
                    const categoryVal = categorySelect ? categorySelect.value : '';
                    fetch(`<?php echo e(route('search.suggestions')); ?>?q=${encodeURIComponent(val)}&category=${encodeURIComponent(categoryVal)}`)
                        .then(res => res.json())
                        .then(data => {
                            let html = '';
                            if (data.products && data.products.length > 0) {
                                html += '<div class="p-2 bg-dark text-uppercase fw-bold text-secondary border-bottom border-secondary border-opacity-25" style="font-size:11px;">Products</div>';
                                data.products.forEach(p => {
                                    html += `
                                        <a href="${p.url}" class="search-item-row">
                                            <img src="${p.image}" alt="${p.name}" onerror="this.onerror=null;this.src='<?php echo e(asset('images/dummy-product.svg')); ?>';">
                                            <div class="flex-grow-1">
                                                <div class="fw-bold font-sm text-light">${p.name}</div>
                                                <div class="text-danger fw-bold font-sm">${p.price}</div>
                                            </div>
                                        </a>
                                    `;
                                });
                            }
                            if (data.models && data.models.length > 0) {
                                html += '<div class="p-2 bg-dark text-uppercase fw-bold text-secondary border-bottom border-secondary border-opacity-25" style="font-size:11px;">Car Models</div>';
                                data.models.forEach(m => {
                                    html += `
                                        <a href="${m.url}" class="search-item-row">
                                            <i class="fa-solid fa-car-side text-danger me-2"></i>
                                            <div class="fw-bold font-sm text-light">${m.name}</div>
                                        </a>
                                    `;
                                });
                            }
                            if (data.brands && data.brands.length > 0) {
                                html += '<div class="p-2 bg-dark text-uppercase fw-bold text-secondary border-bottom border-secondary border-opacity-25" style="font-size:11px;">Brands</div>';
                                data.brands.forEach(b => {
                                    html += `
                                        <a href="${b.url}" class="search-item-row">
                                            <i class="fa-solid fa-car text-danger me-2"></i>
                                            <div class="fw-bold font-sm text-light">${b.name}</div>
                                        </a>
                                    `;
                                });
                            }
                            if (html) {
                                html += `
                                    <a href="<?php echo e(route('shop')); ?>?q=${encodeURIComponent(val)}${categoryVal ? '&category=' + encodeURIComponent(categoryVal) : ''}" class="p-2 bg-dark d-block text-center text-danger fw-bold font-sm text-decoration-none border-top border-secondary border-opacity-25">
                                        <i class="fa-solid fa-magnifying-glass me-1"></i> View all results for "${val}"
                                    </a>
                                `;
                                suggestionsBox.innerHTML = html;
                                suggestionsBox.style.display = 'block';
                            } else {
                                suggestionsBox.style.display = 'none';
                            }
                        });
                }, 250);
            });

            document.addEventListener('click', function(e) {
                if (!searchInput.contains(e.target) && !suggestionsBox.contains(e.target)) {
                    suggestionsBox.style.display = 'none';
                }
            });
        }

        // Global AJAX Wishlist Toggle
        function toggleWishlist(productId, btnElem) {
            fetch(`/wishlist/toggle/${productId}`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': csrfToken,
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    const counter = document.getElementById('globalWishlistCounter');
                    if (counter) counter.innerText = data.wishlist_count;

                    if (btnElem) {
                        const heartIcon = btnElem.querySelector('i');
                        if (heartIcon) {
                            if (data.added) {
                                heartIcon.classList.remove('fa-regular');
                                heartIcon.classList.add('fa-solid', 'text-danger');
                            } else {
                                heartIcon.classList.remove('fa-solid', 'text-danger');
                                heartIcon.classList.add('fa-regular');
                            }
                        }
                    }

                    showToast(data.message, 'success');
                }
            })
            .catch(err => console.error(err));
        }

        // Global AJAX Add to Cart
        function addToCartAjax(productId, variantId = null, qty = 1, callback = null) {
            fetch('<?php echo e(route("cart.add")); ?>', {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': csrfToken,
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    product_id: productId,
                    variant_id: variantId,
                    quantity: qty
                })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    const counter = document.getElementById('globalCartCounter');
                    if (counter) counter.innerText = data.cart_count;
                    showToast(data.message, 'success');
                    if (callback) callback(data);
                } else {
                    showToast(data.message, 'error');
                }
            })
            .catch(err => console.error(err));
        }

        // SweetAlert2 Toast Instance
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            showCloseButton: true,
            timer: 3800,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer);
                toast.addEventListener('mouseleave', Swal.resumeTimer);
            }
        });

        // Global window.alert replacement
        window.alert = function (message) {
            Swal.fire({
                text: message,
                icon: 'info',
                confirmButtonColor: '#d90429',
                confirmButtonText: 'OK',
                customClass: { confirmButton: 'btn-swal-confirm' }
            });
        };

        // Universal Form Confirmation Interceptor
        document.addEventListener('submit', function (e) {
            const form = e.target;
            if (form.dataset.confirmed === 'true') {
                return;
            }

            const confirmMsg = form.getAttribute('data-confirm') || form.getAttribute('data-confirm-message');
            const hasConfirmClass = form.classList.contains('confirm-action') || form.classList.contains('delete-form');
            const onsubmitAttr = form.getAttribute('onsubmit') || '';
            const hasInlineConfirm = onsubmitAttr.includes('confirm(');

            if (confirmMsg || hasConfirmClass || hasInlineConfirm) {
                e.preventDefault();
                e.stopPropagation();

                let msg = confirmMsg;
                if (!msg && hasInlineConfirm) {
                    const match = onsubmitAttr.match(/confirm\(['"](.*?)['"]\)/);
                    if (match && match[1]) {
                        msg = match[1];
                    }
                }
                msg = msg || 'Are you sure you want to proceed?';
                const title = form.getAttribute('data-confirm-title') || 'Are you sure?';
                const btnText = form.getAttribute('data-confirm-btn') || 'Yes, proceed';

                Swal.fire({
                    title: title,
                    text: msg,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d90429',
                    cancelButtonColor: '#64748b',
                    confirmButtonText: btnText,
                    cancelButtonText: 'Cancel',
                    reverseButtons: true,
                    customClass: {
                        confirmButton: 'btn-swal-confirm',
                        cancelButton: 'btn-swal-cancel'
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.dataset.confirmed = 'true';
                        form.submit();
                    }
                });
            }
        }, true);

        // Universal Link Confirmation Interceptor
        document.addEventListener('click', function (e) {
            const link = e.target.closest('a[data-confirm], a[onclick*="confirm("], .confirm-link');
            if (!link) return;

            if (link.dataset.confirmed === 'true') {
                return;
            }

            e.preventDefault();
            e.stopPropagation();

            let msg = link.getAttribute('data-confirm');
            const onclickAttr = link.getAttribute('onclick') || '';
            if (!msg && onclickAttr.includes('confirm(')) {
                const match = onclickAttr.match(/confirm\(['"](.*?)['"]\)/);
                if (match && match[1]) {
                    msg = match[1];
                }
            }
            msg = msg || 'Are you sure you want to proceed?';
            const title = link.getAttribute('data-confirm-title') || 'Are you sure?';
            const btnText = link.getAttribute('data-confirm-btn') || 'Yes, proceed';

            Swal.fire({
                title: title,
                text: msg,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d90429',
                cancelButtonColor: '#64748b',
                confirmButtonText: btnText,
                cancelButtonText: 'Cancel',
                reverseButtons: true,
                customClass: {
                    confirmButton: 'btn-swal-confirm',
                    cancelButton: 'btn-swal-cancel'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    link.dataset.confirmed = 'true';
                    window.location.href = link.href;
                }
            });
        }, true);

        // Upgraded showToast to SweetAlert2
        window.showToast = function (msg, type = 'info') {
            const iconType = ['success', 'error', 'warning', 'info', 'question'].includes(type) ? type : 'info';
            Toast.fire({
                icon: iconType,
                title: msg
            });
        };

        // Automatic flash message handling via SweetAlert2
        document.addEventListener('DOMContentLoaded', function () {
            <?php if(session('success')): ?>
                Toast.fire({
                    icon: 'success',
                    title: "<?php echo e(addslashes(session('success'))); ?>"
                });
            <?php endif; ?>

            <?php if(session('error')): ?>
                Swal.fire({
                    icon: 'error',
                    title: 'Action Failed',
                    text: "<?php echo e(addslashes(session('error'))); ?>",
                    confirmButtonColor: '#d90429',
                    customClass: { confirmButton: 'btn-swal-confirm' }
                });
            <?php endif; ?>

            <?php if(session('warning')): ?>
                Toast.fire({
                    icon: 'warning',
                    title: "<?php echo e(addslashes(session('warning'))); ?>"
                });
            <?php endif; ?>

            <?php if(session('info')): ?>
                Toast.fire({
                    icon: 'info',
                    title: "<?php echo e(addslashes(session('info'))); ?>"
                });
            <?php endif; ?>

            <?php if(session('status')): ?>
                Toast.fire({
                    icon: 'info',
                    title: "<?php echo e(addslashes(session('status'))); ?>"
                });
            <?php endif; ?>

            <?php if($errors->any()): ?>
                Swal.fire({
                    icon: 'error',
                    title: 'Validation Errors',
                    html: '<ul class="text-start mb-0 ps-3"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e(addslashes($err)); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>',
                    confirmButtonColor: '#d90429',
                    customClass: { confirmButton: 'btn-swal-confirm' }
                });
            <?php endif; ?>
        });
    </script>

    <!-- jQuery & Select2 JS -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        function applySelect2(context) {
            if (!window.jQuery || !$.fn.select2) return;
            const $root = context ? $(context) : $(document);

            // 1. Initialize Quick Vehicle Selector on homepage (Dark Theme)
            $root.find('#vehicleQuickSearchForm select').each(function() {
                const $s = $(this);
                if ($s.hasClass('no-select2') || $s.hasClass('select2-hidden-accessible')) {
                    return;
                }

                const firstOptionText = $s.find('option:first-child').text() || 'Search';
                const searchPrompt = firstOptionText.replace(/^[0-9]+\.\s*/, 'Search ') + '...';

                $s.select2({
                    width: '100%',
                    dropdownAutoWidth: false,
                    dropdownCssClass: 'quick-search-dropdown',
                    minimumResultsForSearch: 4,
                    templateResult: function(data) {
                        // Hide empty placeholder from the dropdown list
                        if (!data.id) {
                            return null;
                        }
                        return data.text;
                    }
                });

                // Dynamically set search input placeholder on open
                $s.on('select2:open', function() {
                    setTimeout(function() {
                        const searchField = document.querySelector('.select2-container--open .select2-search__field');
                        if (searchField) {
                            searchField.placeholder = searchPrompt;
                        }
                    }, 15);
                });

                $s.on('select2:select select2:unselect', function() {
                    this.dispatchEvent(new Event('change', { bubbles: true }));
                });

                $s.on('change.select2 change', function() {
                    const $container = $s.next('.select2-container');
                    if ($s.prop('disabled')) {
                        $container.addClass('select2-container--disabled');
                    } else {
                        $container.removeClass('select2-container--disabled');
                    }
                });
            });

            // 2. Initialize all other standard frontend selects (Light Theme)
            $root.find('select.form-select, select.select2')
                .not('#vehicleQuickSearchForm select, .search-category-select, .no-select2')
                .each(function() {
                    const $s = $(this);
                    if ($s.hasClass('select2-hidden-accessible')) {
                        return;
                    }

                    const isSm = $s.hasClass('form-select-sm');
                    const optCount = $s.find('option').length;
                    const isFilter = $s.attr('name') === 'brand' || $s.attr('name') === 'model' || $s.attr('name') === 'variant';
                    const hasExplicitWidth = $s[0].style.width && $s[0].style.width !== '';
                    const widthVal = hasExplicitWidth ? $s[0].style.width : '100%';

                    $s.select2({
                        width: widthVal,
                        dropdownAutoWidth: false,
                        minimumResultsForSearch: (optCount <= 5 && !isFilter) ? Infinity : 4,
                        dropdownCssClass: 'select2-dropdown-light',
                        containerCssClass: isSm ? 'select2-container-sm' : ''
                    });

                    $s.on('select2:select select2:unselect', function() {
                        this.dispatchEvent(new Event('change', { bubbles: true }));
                    });

                    $s.on('change.select2 change', function() {
                        const $container = $s.next('.select2-container');
                        if ($s.prop('disabled')) {
                            $container.addClass('select2-container--disabled');
                        } else {
                            $container.removeClass('select2-container--disabled');
                        }
                    });
                });
        }

        $(document).ready(function() {
            applySelect2();

            // Smart Scroll-Up Sticky Header with smooth slide-down animation
            (function() {
                const container = document.getElementById('stickyHeaderContainer');
                const inner = document.getElementById('stickyHeaderInner');
                if (!container || !inner) return;

                let lastScrollY = window.pageYOffset || document.documentElement.scrollTop;
                let ticking = false;
                const threshold = 6;

                function getHeaderHeight() {
                    return inner.offsetHeight || 115;
                }

                function updateScroll() {
                    const currentScrollY = window.pageYOffset || document.documentElement.scrollTop;
                    const headerH = getHeaderHeight();
                    const delta = currentScrollY - lastScrollY;

                    // Near the top of page: revert to normal static flow
                    if (currentScrollY <= headerH + 35) {
                        container.classList.remove('is-sticky', 'header-visible', 'header-hidden');
                        container.style.minHeight = '';
                        lastScrollY = Math.max(0, currentScrollY);
                        ticking = false;
                        return;
                    }

                    // Ignore tiny scroll jitter
                    if (Math.abs(delta) < threshold) {
                        ticking = false;
                        return;
                    }

                    if (delta > 0) {
                        // Scrolling DOWN -> slide header up out of view
                        if (!container.classList.contains('is-sticky')) {
                            container.style.minHeight = headerH + 'px';
                            container.classList.add('is-sticky');
                        }
                        container.classList.remove('header-visible');
                        container.classList.add('header-hidden');
                    } else {
                        // Scrolling UP -> slide header DOWN smoothly into view
                        if (!container.classList.contains('is-sticky')) {
                            container.style.minHeight = headerH + 'px';
                            container.classList.add('is-sticky');
                        }
                        container.classList.remove('header-hidden');
                        container.classList.add('header-visible');
                    }

                    lastScrollY = Math.max(0, currentScrollY);
                    ticking = false;
                }

                window.addEventListener('scroll', function() {
                    if (!ticking) {
                        window.requestAnimationFrame(updateScroll);
                        ticking = true;
                    }
                }, { passive: true });

                window.addEventListener('resize', function() {
                    if (container.classList.contains('is-sticky')) {
                        container.style.minHeight = getHeaderHeight() + 'px';
                    }
                });
            })();
        });
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\Laravel\skm\resources\views/layouts/app.blade.php ENDPATH**/ ?>