<?php $__env->startSection('title', 'Roles & Permissions - SKM Saller Admin'); ?>
<?php $__env->startSection('page_title', 'Roles & Permissions Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-0">
    <!-- Header with Action Button -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
        <div>
            <h4 class="fw-bold text-dark mb-1">
                <i class="fa-solid fa-shield-halved text-danger me-2"></i> Role Management System
            </h4>
            <p class="text-muted small mb-0">Create and configure user roles and specify granular access permissions across the system.</p>
        </div>
        <div class="d-flex align-items-center gap-2">
            <a href="<?php echo e(route('admin.staff.index')); ?>" class="btn btn-outline-secondary btn-sm shadow-xs d-inline-flex align-items-center gap-2">
                <i class="fa-solid fa-users"></i> Staff & Team
            </a>
            <a href="<?php echo e(route('admin.roles.create')); ?>" class="btn btn-danger btn-sm shadow-xs d-inline-flex align-items-center gap-2">
                <i class="fa-solid fa-plus-circle"></i> Create New Role
            </a>
        </div>
    </div>

    <!-- Roles Grid / Table -->
    <div class="card border-0 shadow-sm rounded-3 bg-white mb-4">
        <div class="card-header bg-white border-bottom py-3 d-flex justify-content-between align-items-center">
            <h6 class="fw-bold mb-0 text-dark">
                <i class="fa-solid fa-list-check text-primary me-2"></i> All System & Custom Roles (<?php echo e($roles->count()); ?>)
            </h6>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 font-sm">
                <thead class="bg-light text-muted text-uppercase small" style="font-size: 11px; letter-spacing: 0.5px;">
                    <tr>
                        <th class="ps-4 py-3">Role Name</th>
                        <th class="py-3">Slug Identifier</th>
                        <th class="py-3">Type</th>
                        <th class="py-3">Assigned Staff</th>
                        <th class="py-3">Permissions</th>
                        <th class="py-3 text-end pe-4">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="ps-4">
                                <div class="d-flex align-items-center gap-2">
                                    <div class="rounded-circle d-flex align-items-center justify-content-center <?php echo e($role->isSuperAdmin() ? 'bg-danger text-white' : ($role->slug === 'staff' ? 'bg-primary text-white' : (in_array($role->slug, ['user', 'customer']) ? 'bg-secondary-subtle text-secondary' : 'bg-success-subtle text-success'))); ?>" style="width: 36px; height: 36px;">
                                        <i class="fa-solid <?php echo e($role->isSuperAdmin() ? 'fa-crown' : ($role->slug === 'staff' ? 'fa-user-shield' : (in_array($role->slug, ['user', 'customer']) ? 'fa-user' : 'fa-id-badge'))); ?>"></i>
                                    </div>
                                    <div>
                                        <div class="fw-bold text-dark"><?php echo e($role->name); ?></div>
                                        <div class="text-muted small text-truncate" style="max-width: 250px;"><?php echo e($role->description ?: 'No description provided.'); ?></div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <code class="bg-light px-2 py-1 rounded text-danger fw-semibold"><?php echo e($role->slug); ?></code>
                            </td>
                            <td>
                                <?php if($role->isSuperAdmin()): ?>
                                    <span class="badge bg-danger text-white"><i class="fa-solid fa-crown me-1"></i> Super Admin</span>
                                <?php elseif($role->slug === 'staff'): ?>
                                    <span class="badge bg-primary text-white"><i class="fa-solid fa-user-shield me-1"></i> Staff</span>
                                <?php elseif(in_array($role->slug, ['user', 'customer'])): ?>
                                    <span class="badge bg-secondary-subtle text-dark border border-secondary"><i class="fa-solid fa-user me-1"></i> Customer</span>
                                <?php elseif($role->isSystem()): ?>
                                    <span class="badge bg-primary-subtle text-primary border border-primary"><i class="fa-solid fa-lock me-1"></i> System Role</span>
                                <?php else: ?>
                                    <span class="badge bg-success-subtle text-success border border-success"><i class="fa-solid fa-puzzle-piece me-1"></i> Custom Role</span>
                                <?php endif; ?>

                                <?php if($role->is_admin): ?>
                                    <span class="badge bg-info-subtle text-info ms-1">Admin Access</span>
                                <?php else: ?>
                                    <span class="badge bg-light text-muted border ms-1">Store Customer</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($role->isUser() || !$role->is_admin): ?>
                                    <a href="<?php echo e(route('admin.customers.index')); ?>" class="badge bg-light text-dark border text-decoration-none px-2 py-1" title="View Registered Customers">
                                        <i class="fa-solid fa-users me-1 text-primary"></i> <?php echo e($role->users_count); ?> customer(s)
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('admin.staff.index', ['role' => $role->id])); ?>" class="badge bg-light text-dark border text-decoration-none px-2 py-1" title="View Assigned Staff">
                                        <i class="fa-solid fa-users me-1 text-primary"></i> <?php echo e($role->users_count); ?> member(s)
                                    </a>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($role->isSuperAdmin()): ?>
                                    <span class="badge bg-danger-subtle text-danger border border-danger">
                                        <i class="fa-solid fa-infinity me-1"></i> Full Access (All Permissions)
                                    </span>
                                <?php elseif($role->isUser()): ?>
                                    <span class="badge bg-secondary-subtle text-muted border">
                                        <i class="fa-solid fa-ban me-1 text-danger"></i> No Admin Permissions (Customer Role)
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-light text-dark border">
                                        <i class="fa-solid fa-key me-1 text-warning"></i> <?php echo e($role->permissions_count); ?> permission(s)
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end pe-4">
                                <div class="d-inline-flex gap-2">
                                    <a href="<?php echo e(route('admin.roles.edit', $role->id)); ?>" class="btn btn-sm btn-outline-primary" title="Edit Role & Permissions">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </a>

                                    <?php if(!$role->isSystem() && $role->users_count === 0): ?>
                                        <form action="<?php echo e(route('admin.roles.destroy', $role->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete role <?php echo e($role->name); ?>?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete Role">
                                                <i class="fa-solid fa-trash-can"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center py-5 text-muted">
                                <i class="fa-solid fa-shield-halved fs-1 text-secondary mb-3 d-block"></i>
                                No roles found.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\skm\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>