<?php $__env->startSection('title', 'Admin Dashboard - SKM Saller'); ?>
<?php $__env->startSection('page_title', 'Dashboard Overview'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-0">
    <!-- Dual Dashboard Switcher Bar -->
    <div class="card border-0 shadow-sm rounded-3 mb-4 bg-white">
        <div class="card-body p-3 d-flex flex-wrap align-items-center justify-content-between gap-3">
            <div class="d-flex align-items-center gap-2">
                <span class="text-muted small fw-bold text-uppercase d-none d-md-inline" style="font-size: 11px; letter-spacing: 1px;">Admin Views:</span>
                <ul class="nav nav-pills gap-2 p-1 bg-light rounded-3 border">
                    <li class="nav-item">
                        <a class="nav-link py-2 px-3 fw-bold font-sm active bg-danger text-white shadow-sm" href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="fa-solid fa-gauge-high me-1"></i> Sales & Orders Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link py-2 px-3 fw-bold font-sm text-secondary" href="<?php echo e(route('admin.catalog.analytics')); ?>">
                            <i class="fa-solid fa-chart-pie me-1 text-danger"></i> Catalog & Vehicle Analytics
                            <span class="badge bg-danger ms-1" style="font-size: 8px;">LIVE</span>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="d-flex align-items-center gap-2">
                <a href="<?php echo e(route('admin.catalog.analytics')); ?>" class="btn btn-sm btn-outline-danger fw-semibold">
                    <i class="fa-solid fa-chart-pie me-1"></i> Open Catalog Analytics
                </a>
            </div>
        </div>
    </div>

    <!-- Top KPI Cards -->
    <div class="row g-3 mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="card border-0 shadow-sm rounded-3 h-100 bg-white">
                <div class="card-body p-4 d-flex align-items-center justify-content-between">
                    <div>
                        <div class="text-muted small text-uppercase fw-bold mb-1" style="font-size: 11px; letter-spacing: 1px;">Total Revenue (Paid)</div>
                        <h3 class="fw-bold mb-0 text-dark">&#x20B9;<?php echo e(number_format($totalSales, 2)); ?></h3>
                        <div class="text-success small mt-2 fw-semibold">
                            <i class="fa-solid fa-arrow-trend-up me-1"></i> Today: &#x20B9;<?php echo e(number_format($todaySales, 2)); ?>

                        </div>
                    </div>
                    <div class="rounded-3 p-3 text-white d-flex align-items-center justify-content-center" style="background: linear-gradient(135deg, #10b981, #059669); width: 56px; height: 56px;">
                        <i class="fa-solid fa-indian-rupee-sign fs-4"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="card border-0 shadow-sm rounded-3 h-100 bg-white">
                <div class="card-body p-4 d-flex align-items-center justify-content-between">
                    <div>
                        <div class="text-muted small text-uppercase fw-bold mb-1" style="font-size: 11px; letter-spacing: 1px;">Total Orders</div>
                        <h3 class="fw-bold mb-0 text-dark"><?php echo e(number_format($totalOrders)); ?></h3>
                        <div class="text-primary small mt-2 fw-semibold">
                            <i class="fa-solid fa-clock me-1"></i> <?php echo e($pendingOrders); ?> Pending confirmation
                        </div>
                    </div>
                    <div class="rounded-3 p-3 text-white d-flex align-items-center justify-content-center" style="background: linear-gradient(135deg, #3b82f6, #1d4ed8); width: 56px; height: 56px;">
                        <i class="fa-solid fa-bag-shopping fs-4"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="card border-0 shadow-sm rounded-3 h-100 bg-white">
                <div class="card-body p-4 d-flex align-items-center justify-content-between">
                    <div>
                        <div class="text-muted small text-uppercase fw-bold mb-1" style="font-size: 11px; letter-spacing: 1px;">Registered Customers</div>
                        <h3 class="fw-bold mb-0 text-dark"><?php echo e(number_format($totalCustomers)); ?></h3>
                        <div class="text-muted small mt-2">
                            <i class="fa-solid fa-shield-halved me-1 text-success"></i> Active buyers & accounts
                        </div>
                    </div>
                    <div class="rounded-3 p-3 text-white d-flex align-items-center justify-content-center" style="background: linear-gradient(135deg, #8b5cf6, #6d28d9); width: 56px; height: 56px;">
                        <i class="fa-solid fa-users fs-4"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="card border-0 shadow-sm rounded-3 h-100 bg-white">
                <div class="card-body p-4 d-flex align-items-center justify-content-between">
                    <div>
                        <div class="text-muted small text-uppercase fw-bold mb-1" style="font-size: 11px; letter-spacing: 1px;">Catalog Products</div>
                        <h3 class="fw-bold mb-0 text-dark"><?php echo e(number_format($totalProducts)); ?></h3>
                        <div class="text-danger small mt-2 fw-semibold">
                            <i class="fa-solid fa-triangle-exclamation me-1"></i> <?php echo e($lowStockProducts); ?> Low / Out of Stock
                        </div>
                    </div>
                    <div class="rounded-3 p-3 text-white d-flex align-items-center justify-content-center" style="background: linear-gradient(135deg, #f59e0b, #d97706); width: 56px; height: 56px;">
                        <i class="fa-solid fa-boxes-stacked fs-4"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Status Counter Pills -->
    <div class="row g-2 mb-4">
        <div class="col-6 col-md">
            <a href="<?php echo e(route('admin.orders.index', ['status' => 'pending'])); ?>" class="card text-decoration-none border-0 shadow-sm bg-warning bg-opacity-10 text-warning-emphasis p-3 rounded-3 text-center">
                <div class="fs-4 fw-bold"><?php echo e($pendingOrders); ?></div>
                <div class="small fw-semibold">Pending</div>
            </a>
        </div>
        <div class="col-6 col-md">
            <a href="<?php echo e(route('admin.orders.index', ['status' => 'processing'])); ?>" class="card text-decoration-none border-0 shadow-sm bg-info bg-opacity-10 text-info-emphasis p-3 rounded-3 text-center">
                <div class="fs-4 fw-bold"><?php echo e($processingOrders); ?></div>
                <div class="small fw-semibold">Processing/Packed</div>
            </a>
        </div>
        <div class="col-6 col-md">
            <a href="<?php echo e(route('admin.orders.index', ['status' => 'shipped'])); ?>" class="card text-decoration-none border-0 shadow-sm bg-primary bg-opacity-10 text-primary-emphasis p-3 rounded-3 text-center">
                <div class="fs-4 fw-bold"><?php echo e($shippedOrders); ?></div>
                <div class="small fw-semibold">Shipped/In Transit</div>
            </a>
        </div>
        <div class="col-6 col-md">
            <a href="<?php echo e(route('admin.orders.index', ['status' => 'delivered'])); ?>" class="card text-decoration-none border-0 shadow-sm bg-success bg-opacity-10 text-success-emphasis p-3 rounded-3 text-center">
                <div class="fs-4 fw-bold"><?php echo e($deliveredOrders); ?></div>
                <div class="small fw-semibold">Delivered</div>
            </a>
        </div>
        <div class="col-6 col-md">
            <a href="<?php echo e(route('admin.orders.index', ['status' => 'cancelled'])); ?>" class="card text-decoration-none border-0 shadow-sm bg-danger bg-opacity-10 text-danger p-3 rounded-3 text-center">
                <div class="fs-4 fw-bold"><?php echo e($cancelledOrders); ?></div>
                <div class="small fw-semibold">Cancelled</div>
            </a>
        </div>
    </div>

    <!-- Customer Support Inquiries (Prominent Upper Dashboard Widget) -->
    <div class="card border-0 shadow-sm rounded-3 bg-white mb-4">
        <div class="card-header bg-white border-bottom py-3 d-flex flex-wrap justify-content-between align-items-center gap-2">
            <div class="d-flex align-items-center gap-2">
                <div class="rounded-circle bg-danger bg-opacity-10 text-danger d-flex align-items-center justify-content-center" style="width: 38px; height: 38px;">
                    <i class="fa-solid fa-headset fs-5"></i>
                </div>
                <div>
                    <h6 class="mb-0 fw-bold text-dark d-flex align-items-center gap-2">
                        Customer Support Inquiries & Messages
                        <?php if(($unreadInquiriesCount ?? 0) > 0): ?>
                            <span class="badge bg-danger rounded-pill px-2 py-1" style="font-size: 11px;">
                                <i class="fa-solid fa-bell me-1"></i> <?php echo e($unreadInquiriesCount); ?> Unread
                            </span>
                        <?php else: ?>
                            <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1" style="font-size: 11px;">
                                <i class="fa-solid fa-check-double me-1"></i> All Resolved
                            </span>
                        <?php endif; ?>
                    </h6>
                    <small class="text-muted">Direct messages submitted from the contact form or vehicle fitment help requests.</small>
                </div>
            </div>
            <div class="d-flex align-items-center gap-2">
                <a href="<?php echo e(route('admin.inquiries.index')); ?>" class="btn btn-sm btn-outline-danger fw-semibold">
                    <i class="fa-solid fa-envelope-open-text me-1"></i> View All Inquiries (<?php echo e($totalInquiriesCount ?? 0); ?>)
                </a>
            </div>
        </div>
        <div class="card-body p-0">
            <?php if(isset($recentInquiries) && $recentInquiries->isNotEmpty()): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-3" style="width: 220px;">Customer Details</th>
                                <th>Subject & Message Preview</th>
                                <th style="width: 160px;">Received At</th>
                                <th style="width: 120px;">Status</th>
                                <th class="text-end pe-3" style="width: 170px;">Quick Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $recentInquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="<?php echo e(!$inq->is_read ? 'bg-danger bg-opacity-10' : ''); ?>">
                                    <td class="ps-3">
                                        <div class="fw-bold text-dark"><?php echo e($inq->name); ?></div>
                                        <div class="small text-muted d-flex align-items-center gap-1">
                                            <i class="fa-solid fa-phone text-secondary" style="font-size: 10px;"></i>
                                            <?php echo e($inq->phone ?: 'No phone'); ?>

                                        </div>
                                        <div class="small text-muted text-truncate" style="max-width: 200px;">
                                            <i class="fa-solid fa-envelope text-secondary" style="font-size: 10px;"></i>
                                            <?php echo e($inq->email); ?>

                                        </div>
                                    </td>
                                    <td>
                                        <div class="fw-semibold text-dark small mb-1">
                                            <?php echo e($inq->subject ?: 'General Customer Inquiry'); ?>

                                        </div>
                                        <p class="text-muted small mb-0 text-truncate" style="max-width: 480px;">
                                            <?php echo e(Str::limit($inq->message, 120)); ?>

                                        </p>
                                    </td>
                                    <td class="small text-muted">
                                        <span title="<?php echo e($inq->created_at->format('d M Y, h:i A')); ?>">
                                            <?php echo e($inq->created_at->diffForHumans()); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <?php if(!$inq->is_read): ?>
                                            <span class="badge bg-danger shadow-sm">
                                                <i class="fa-solid fa-circle-exclamation me-1"></i> New Unread
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-light text-muted border">Read</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end pe-3">
                                        <div class="btn-group btn-group-sm">
                                            <?php if(!$inq->is_read): ?>
                                                <form action="<?php echo e(route('admin.inquiries.read', $inq->id)); ?>" method="POST" class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-light border text-success" title="Mark as Read">
                                                        <i class="fa-solid fa-check"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                            <?php if($inq->phone): ?>
                                                <a href="https://wa.me/91<?php echo e(preg_replace('/[^0-9]/', '', $inq->phone)); ?>" target="_blank" class="btn btn-light border text-success" title="WhatsApp Customer">
                                                    <i class="fa-brands fa-whatsapp"></i>
                                                </a>
                                            <?php endif; ?>
                                            <a href="mailto:<?php echo e($inq->email); ?>?subject=Re: <?php echo e(urlencode($inq->subject ?: 'SKM Saller Support')); ?>" class="btn btn-light border text-primary" title="Reply via Email">
                                                <i class="fa-solid fa-reply"></i>
                                            </a>
                                            <button type="button" class="btn btn-light border text-dark" data-bs-toggle="modal" data-bs-target="#inquiryModal<?php echo e($inq->id); ?>" title="View Full Message">
                                                <i class="fa-solid fa-eye"></i>
                                            </button>
                                        </div>

                                        <!-- Message Detail Modal -->
                                        <div class="modal fade text-start" id="inquiryModal<?php echo e($inq->id); ?>" tabindex="-1" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content rounded-3 border-0 shadow">
                                                    <div class="modal-header bg-light">
                                                        <h6 class="modal-title fw-bold text-dark">
                                                            <i class="fa-solid fa-envelope me-2 text-danger"></i> Message from <?php echo e($inq->name); ?>

                                                        </h6>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body p-4">
                                                        <div class="mb-3">
                                                            <span class="text-muted small">From:</span>
                                                            <div class="fw-bold text-dark"><?php echo e($inq->name); ?> &lt;<?php echo e($inq->email); ?>&gt;</div>
                                                            <?php if($inq->phone): ?>
                                                                <div class="small text-muted"><i class="fa-solid fa-phone me-1"></i> <?php echo e($inq->phone); ?></div>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="mb-3">
                                                            <span class="text-muted small">Subject:</span>
                                                            <div class="fw-semibold text-dark"><?php echo e($inq->subject ?: 'General Inquiry'); ?></div>
                                                        </div>
                                                        <div class="mb-3">
                                                            <span class="text-muted small">Message:</span>
                                                            <div class="p-3 bg-light rounded-3 text-dark small border" style="white-space: pre-wrap;"><?php echo e($inq->message); ?></div>
                                                        </div>
                                                        <div class="small text-muted">
                                                            <i class="fa-solid fa-clock me-1"></i> Submitted on <?php echo e($inq->created_at->format('d M Y, h:i A')); ?> (<?php echo e($inq->created_at->diffForHumans()); ?>)
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer bg-light border-0">
                                                        <?php if($inq->phone): ?>
                                                            <a href="https://wa.me/91<?php echo e(preg_replace('/[^0-9]/', '', $inq->phone)); ?>" target="_blank" class="btn btn-sm btn-success">
                                                                <i class="fa-brands fa-whatsapp me-1"></i> WhatsApp
                                                            </a>
                                                        <?php endif; ?>
                                                        <a href="mailto:<?php echo e($inq->email); ?>?subject=Re: <?php echo e(urlencode($inq->subject ?: 'SKM Saller Support')); ?>" class="btn btn-sm btn-primary">
                                                            <i class="fa-solid fa-reply me-1"></i> Email Reply
                                                        </a>
                                                        <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-4 text-muted">
                    <i class="fa-solid fa-circle-check text-success fs-3 mb-2 d-block"></i>
                    <p class="mb-0 fw-semibold">No pending customer support inquiries.</p>
                    <small class="text-muted">All customer messages submitted through the website have been attended to.</small>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Chart & Top Products Row -->
    <div class="row g-3 mb-4">
        <!-- Revenue Chart -->
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm rounded-3 bg-white h-100">
                <div class="card-header bg-white border-bottom py-3 d-flex flex-wrap justify-content-between align-items-center gap-2">
                    <h6 class="mb-0 fw-bold text-dark"><i class="fa-solid fa-chart-column text-danger me-2"></i> Revenue & Order Trend <span class="text-muted fw-normal small"><?php echo e($timeframeTitle); ?></span></h6>
                    <div class="btn-group btn-group-sm" role="group" aria-label="Timeframe selection">
                        <a href="<?php echo e(route('admin.dashboard', ['timeframe' => '30days'])); ?>" class="btn <?php echo e(($timeframe ?? '6months') === '30days' ? 'btn-danger' : 'btn-outline-secondary'); ?>">30 Days</a>
                        <a href="<?php echo e(route('admin.dashboard', ['timeframe' => '6months'])); ?>" class="btn <?php echo e(($timeframe ?? '6months') === '6months' ? 'btn-danger' : 'btn-outline-secondary'); ?>">6 Months</a>
                        <a href="<?php echo e(route('admin.dashboard', ['timeframe' => 'year'])); ?>" class="btn <?php echo e(($timeframe ?? '6months') === 'year' ? 'btn-danger' : 'btn-outline-secondary'); ?>">1 Year</a>
                    </div>
                </div>
                <div class="card-body p-4">
                    <div style="height: 280px; position: relative;">
                        <canvas id="revenueChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Top Selling Products -->
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm rounded-3 bg-white h-100">
                <div class="card-header bg-white border-bottom py-3 d-flex justify-content-between align-items-center">
                    <h6 class="mb-0 fw-bold text-dark"><i class="fa-solid fa-trophy text-warning me-2"></i> Top Selling Emblems</h6>
                    <a href="<?php echo e(route('admin.products.index')); ?>" class="small text-decoration-none text-danger fw-semibold">View All</a>
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush">
                        <?php $__empty_1 = true; $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="list-group-item d-flex align-items-center gap-3 py-3 px-3">
                                <div class="bg-light rounded p-1 border text-center" style="width: 48px; height: 48px; flex-shrink: 0;">
                                    <img src="<?php echo e(asset($tp->primary_image_url)); ?>" alt="<?php echo e($tp->name); ?>" class="img-fluid h-100 object-fit-contain">
                                </div>
                                <div class="flex-grow-1 overflow-hidden">
                                    <a href="<?php echo e(route('admin.products.edit', $tp->id)); ?>" class="text-dark fw-bold text-decoration-none text-truncate d-block small mb-1">
                                        <?php echo e($tp->name); ?>

                                    </a>
                                    <div class="text-muted" style="font-size: 11px;">
                                        SKU: <?php echo e($tp->sku); ?> &bull; Stock: <span class="<?php echo e($tp->stock_quantity <= 5 ? 'text-danger fw-bold' : 'text-success'); ?>"><?php echo e($tp->stock_quantity); ?></span>
                                    </div>
                                </div>
                                <div class="text-end">
                                    <span class="badge bg-danger rounded-pill"><?php echo e($tp->total_sold ?? 0); ?> sold</span>
                                    <div class="small fw-bold text-dark mt-1">&#x20B9;<?php echo e(number_format($tp->final_price)); ?></div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center text-muted p-4">
                                <i class="fa-solid fa-box-open fs-3 mb-2 d-block"></i> No sales recorded yet.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Orders Table -->
    <div class="card border-0 shadow-sm rounded-3 bg-white">
        <div class="card-header bg-white border-bottom py-3 d-flex justify-content-between align-items-center">
            <h6 class="mb-0 fw-bold text-dark"><i class="fa-solid fa-list-check text-danger me-2"></i> Recent Orders</h6>
            <a href="<?php echo e(route('admin.orders.index')); ?>" class="btn btn-sm btn-outline-danger fw-semibold">
                View All Orders <i class="fa-solid fa-arrow-right ms-1"></i>
            </a>
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4">Order #</th>
                        <th>Customer</th>
                        <th>Date</th>
                        <th>Items</th>
                        <th>Total Amount</th>
                        <th>Payment</th>
                        <th>Order Status</th>
                        <th class="text-end pe-4">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="ps-4">
                                <a href="<?php echo e(route('admin.orders.show', $order->id)); ?>" class="fw-bold text-danger text-decoration-none">
                                    #<?php echo e($order->order_number); ?>

                                </a>
                            </td>
                            <td>
                                <div class="fw-semibold text-dark"><?php echo e($order->customer_name); ?></div>
                                <small class="text-muted"><?php echo e($order->customer_phone); ?></small>
                            </td>
                            <td class="text-muted small">
                                <?php echo e($order->created_at->format('d M Y, h:i A')); ?>

                            </td>
                            <td>
                                <span class="badge bg-light text-dark border"><?php echo e($order->items_count ?? $order->items->count()); ?> items</span>
                            </td>
                            <td class="fw-bold text-dark">
                                &#x20B9;<?php echo e(number_format($order->total_amount, 2)); ?>

                            </td>
                            <td>
                                <?php if($order->payment_status === 'paid'): ?>
                                    <span class="badge bg-success-subtle text-success border border-success-subtle"><i class="fa-solid fa-circle-check me-1"></i> Paid (<?php echo e(strtoupper($order->payment_method)); ?>)</span>
                                <?php else: ?>
                                    <span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle"><i class="fa-solid fa-clock me-1"></i> <?php echo e(strtoupper($order->payment_status)); ?> (<?php echo e(strtoupper($order->payment_method)); ?>)</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php
                                    $statusColors = [
                                        'pending' => 'bg-warning-subtle text-warning-emphasis border-warning-subtle',
                                        'confirmed' => 'bg-info-subtle text-info-emphasis border-info-subtle',
                                        'processing' => 'bg-primary-subtle text-primary-emphasis border-primary-subtle',
                                        'packed' => 'bg-secondary-subtle text-secondary-emphasis border-secondary-subtle',
                                        'shipped' => 'bg-primary text-white',
                                        'out_for_delivery' => 'bg-info text-white',
                                        'delivered' => 'bg-success text-white',
                                        'cancelled' => 'bg-danger text-white',
                                    ];
                                    $badgeClass = $statusColors[$order->order_status] ?? 'bg-light text-dark border';
                                ?>
                                <span class="badge <?php echo e($badgeClass); ?> text-uppercase" style="font-size: 11px;">
                                    <?php echo e(str_replace('_', ' ', $order->order_status)); ?>

                                </span>
                            </td>
                            <td class="text-end pe-4">
                                <a href="<?php echo e(route('admin.orders.show', $order->id)); ?>" class="btn btn-sm btn-light border" title="View Order Details">
                                    <i class="fa-solid fa-eye text-primary"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center py-4 text-muted">
                                No orders received yet.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const canvas = document.getElementById('revenueChart');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        const labels = <?php echo json_encode($chartLabels, 15, 512) ?>;
        const revenueData = <?php echo json_encode($chartRevenue, 15, 512) ?>;
        const ordersData = <?php echo json_encode($chartOrders, 15, 512) ?>;

        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [
                    {
                        type: 'line',
                        label: 'Orders Count',
                        data: ordersData,
                        borderColor: '#2563eb',
                        backgroundColor: '#ffffff',
                        borderWidth: 3,
                        pointBackgroundColor: '#2563eb',
                        pointBorderColor: '#ffffff',
                        pointBorderWidth: 2,
                        pointRadius: 4.5,
                        pointHoverRadius: 6.5,
                        fill: false,
                        tension: 0.3,
                        yAxisID: 'y1',
                        order: 1
                    },
                    {
                        type: 'bar',
                        label: 'Revenue (₹)',
                        data: revenueData,
                        backgroundColor: 'rgba(217, 4, 41, 0.8)',
                        hoverBackgroundColor: '#d90429',
                        borderRadius: 6,
                        maxBarThickness: 38,
                        yAxisID: 'y',
                        order: 2
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    mode: 'index',
                    intersect: false,
                },
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Revenue (₹)',
                            color: '#64748b',
                            font: { size: 11, weight: '600' }
                        },
                        ticks: {
                            callback: function(value) {
                                return '₹' + Number(value).toLocaleString('en-IN');
                            },
                            color: '#64748b',
                            font: { size: 11 }
                        },
                        grid: {
                            color: '#f1f5f9'
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Orders',
                            color: '#64748b',
                            font: { size: 11, weight: '600' }
                        },
                        ticks: {
                            precision: 0,
                            color: '#64748b',
                            font: { size: 11 }
                        },
                        grid: {
                            drawOnChartArea: false
                        }
                    },
                    x: {
                        ticks: {
                            color: '#64748b',
                            font: { size: 11 }
                        },
                        grid: {
                            display: false
                        }
                    }
                },
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            usePointStyle: true,
                            boxWidth: 8,
                            boxHeight: 8,
                            padding: 16,
                            font: { size: 12, weight: '600' }
                        }
                    },
                    tooltip: {
                        backgroundColor: '#0f172a',
                        padding: 12,
                        cornerRadius: 8,
                        callbacks: {
                            label: function(context) {
                                if (context.dataset.yAxisID === 'y') {
                                    return ' Revenue: ₹' + Number(context.raw).toLocaleString('en-IN');
                                }
                                return ' Orders: ' + context.raw + (context.raw === 1 ? ' order' : ' orders');
                            }
                        }
                    }
                }
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\skm\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>