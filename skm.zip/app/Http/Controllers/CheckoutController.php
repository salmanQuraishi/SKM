<?php

namespace App\Http\Controllers;

use App\Models\Address;
use App\Models\Order;
use App\Models\Setting;
use App\Services\CartService;
use App\Services\OrderService;
use App\Services\Payment\RazorpayService;
use App\Services\WhatsAppService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class CheckoutController extends Controller
{
    protected CartService $cartService;
    protected OrderService $orderService;
    protected RazorpayService $razorpayService;
    protected WhatsAppService $whatsAppService;

    public function __construct(
        CartService $cartService,
        OrderService $orderService,
        RazorpayService $razorpayService,
        WhatsAppService $whatsAppService
    ) {
        $this->cartService = $cartService;
        $this->orderService = $orderService;
        $this->razorpayService = $razorpayService;
        $this->whatsAppService = $whatsAppService;
    }

    public function index()
    {
        if (!Auth::check()) {
            session()->put('url.intended', route('checkout'));
            return redirect()->route('login')->with('warning', 'Please login to your account or register to place your order.');
        }

        $cart = $this->cartService->getCart();
        if ($cart->items->isEmpty()) {
            return redirect()->route('cart.index')->with('error', 'Your shopping cart is empty.');
        }

        $user = Auth::user();
        $savedAddresses = $user ? $user->addresses()->orderByDesc('is_default')->latest()->get() : collect();

        // If user is logged in but has no saved address record yet, check their last completed order
        if ($user && $savedAddresses->isEmpty()) {
            $lastOrder = Order::where('user_id', $user->id)->whereNotNull('shipping_address')->latest('id')->first();
            if ($lastOrder && is_array($lastOrder->shipping_address)) {
                $ship = $lastOrder->shipping_address;
                if (!empty($ship['address_line_1'])) {
                    $savedAddr = Address::create([
                        'user_id' => $user->id,
                        'name' => $ship['name'] ?? $user->name,
                        'mobile' => $ship['mobile'] ?? $user->phone ?? '',
                        'email' => $ship['email'] ?? $user->email,
                        'address_line_1' => $ship['address_line_1'],
                        'address_line_2' => $ship['address_line_2'] ?? null,
                        'landmark' => $ship['landmark'] ?? null,
                        'city' => $ship['city'] ?? '',
                        'state' => $ship['state'] ?? '',
                        'pincode' => $ship['pincode'] ?? '',
                        'country' => $ship['country'] ?? 'India',
                        'address_type' => 'Home',
                        'is_default' => true,
                    ]);
                    $savedAddresses = collect([$savedAddr]);
                }
            }
        }

        $defaultAddress = $savedAddresses->firstWhere('is_default', true) ?? $savedAddresses->first();

        $totals = $this->cartService->getCartTotals();
        $razorpayKey = $this->razorpayService->getKeyId();
        $razorpayEnabled = $this->razorpayService->isEnabled();
        $isRazorpayConfigured = $this->razorpayService->isConfigured();
        $isTestMode = $this->razorpayService->isTestMode();
        $codEnabled = Setting::get('cod_enabled', Setting::get('enable_cod', '1')) == '1';

        return view('frontend.checkout', compact('cart', 'user', 'savedAddresses', 'defaultAddress', 'totals', 'razorpayKey', 'razorpayEnabled', 'isRazorpayConfigured', 'isTestMode', 'codEnabled'));
    }

    public function process(Request $request)
    {
        if (!Auth::check()) {
            session()->put('url.intended', route('checkout'));
            if ($request->ajax() || $request->expectsJson()) {
                return response()->json([
                    'success' => false,
                    'require_login' => true,
                    'redirect' => route('login'),
                    'message' => 'Please login to your account or register to place your order.'
                ], 401);
            }
            return redirect()->route('login')->with('warning', 'Please login to your account or register to place your order.');
        }

        $user = Auth::user();
        $request->merge([
            'email' => $user->email,
            'mobile' => $user->phone ?: $request->mobile,
            'name' => $request->name ?: $user->name,
        ]);

        $request->validate([
            'name' => 'required|string|max:150',
            'email' => 'required|email|max:150',
            'mobile' => 'required|string|regex:/^[0-9]{10}$/',
            'address_line_1' => 'required|string|max:255',
            'address_line_2' => 'nullable|string|max:255',
            'landmark' => 'nullable|string|max:255',
            'city' => 'required|string|max:100',
            'state' => 'required|string|max:100',
            'pincode' => 'required|string|digits:6',
            'payment_method' => 'required|in:cod,razorpay',
            'customer_notes' => 'nullable|string|max:500',
            'save_address' => 'nullable|boolean',
        ]);

        $user = Auth::user();

        $shippingAddress = [
            'name' => $request->name,
            'mobile' => $request->mobile,
            'email' => $request->email,
            'address_line_1' => $request->address_line_1,
            'address_line_2' => $request->address_line_2,
            'landmark' => $request->landmark,
            'city' => $request->city,
            'state' => $request->state,
            'pincode' => $request->pincode,
            'country' => 'India',
        ];

        $billingAddress = $shippingAddress;

        if ($user && $request->filled('save_address')) {
            Address::create([
                'user_id' => $user->id,
                'name' => $request->name,
                'mobile' => $request->mobile,
                'email' => $request->email,
                'address_line_1' => $request->address_line_1,
                'address_line_2' => $request->address_line_2,
                'landmark' => $request->landmark,
                'city' => $request->city,
                'state' => $request->state,
                'pincode' => $request->pincode,
                'country' => 'India',
                'is_default' => $user->addresses()->count() === 0,
            ]);
        }

        $customerData = [
            'name' => $request->name,
            'email' => $request->email,
            'mobile' => $request->mobile,
        ];

        $paymentMethod = $request->payment_method;

        if ($paymentMethod === 'razorpay' && !$this->razorpayService->isEnabled()) {
            if ($request->ajax() || $request->expectsJson()) {
                return response()->json(['success' => false, 'message' => 'Online payment is currently disabled. Please choose another payment method.'], 422);
            }
            return redirect()->back()->with('error', 'Online payment is currently disabled. Please choose another payment method.')->withInput();
        }

        if ($paymentMethod === 'cod' && Setting::get('cod_enabled', Setting::get('enable_cod', '1')) !== '1') {
            if ($request->ajax() || $request->expectsJson()) {
                return response()->json(['success' => false, 'message' => 'Cash on Delivery is currently disabled. Please choose another payment method.'], 422);
            }
            return redirect()->back()->with('error', 'Cash on Delivery is currently disabled. Please choose another payment method.')->withInput();
        }

        try {
            // Mark any previous unpaid pending order for this customer/session as abandoned
            if ($user) {
                Order::where('user_id', $user->id)
                    ->where('order_status', 'pending')
                    ->where('payment_status', 'pending')
                    ->update([
                        'order_status' => 'abandoned',
                        'cancelled_reason' => 'Superseded by new checkout attempt',
                    ]);
            } elseif (session()->has('last_pending_order_id')) {
                Order::where('id', session('last_pending_order_id'))
                    ->where('order_status', 'pending')
                    ->where('payment_status', 'pending')
                    ->update([
                        'order_status' => 'abandoned',
                        'cancelled_reason' => 'Superseded by new checkout attempt',
                    ]);
            }

            $order = $this->orderService->createOrder(
                $customerData,
                $shippingAddress,
                $billingAddress,
                $paymentMethod,
                $request->customer_notes,
                $user
            );

            if ($paymentMethod === 'cod') {
                session()->forget('last_pending_order_id');
                return redirect()->route('checkout.success', $order->order_number)
                    ->with('success', 'Thank you! Your Cash on Delivery order has been confirmed.');
            }

            session(['last_pending_order_id' => $order->id]);

            // For Online Payment (Razorpay): Create Razorpay Order
            $rzpData = $this->razorpayService->createRazorpayOrder($order);

            return response()->json([
                'success' => true,
                'order_number' => $order->order_number,
                'order_id' => $order->id,
                'razorpay_order_id' => $rzpData['razorpay_order_id'],
                'amount' => $rzpData['amount'],
                'currency' => $rzpData['currency'],
                'key_id' => $rzpData['key_id'],
                'is_mock' => $rzpData['is_mock'] ?? false,
                'customer_name' => $order->customer_name,
                'customer_email' => $order->customer_email,
                'customer_phone' => $order->customer_phone,
            ]);

        } catch (\Exception $e) {
            Log::error('Order creation error: ' . $e->getMessage());
            if ($request->ajax() || $request->expectsJson()) {
                return response()->json(['success' => false, 'message' => $e->getMessage()], 422);
            }
            return redirect()->back()->with('error', $e->getMessage())->withInput();
        }
    }

    public function verifyPayment(Request $request)
    {
        $request->validate([
            'order_number' => 'required|exists:orders,order_number',
            'razorpay_payment_id' => 'required|string',
            'razorpay_order_id' => 'required|string',
            'razorpay_signature' => 'nullable|string',
        ]);

        $order = Order::where('order_number', $request->order_number)->firstOrFail();

        // If already marked as paid (e.g. by webhook), redirect immediately
        if ($order->payment_status === 'paid') {
            session()->forget('last_pending_order_id');
            return response()->json([
                'success' => true,
                'redirect_url' => route('checkout.success', $order->order_number),
            ]);
        }

        $verified = $this->razorpayService->verifyPaymentSignature($request->all());

        if ($verified) {
            $this->orderService->markOrderPaid($order, $request->razorpay_payment_id, $request->all());
            session()->forget('last_pending_order_id');

            return response()->json([
                'success' => true,
                'redirect_url' => route('checkout.success', $order->order_number),
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Payment verification failed. Please contact customer support.',
        ], 400);
    }

    public function success(string $orderNumber)
    {
        $order = Order::where('order_number', $orderNumber)
            ->with(['items.product', 'invoice', 'receipt', 'latestPayment'])
            ->firstOrFail();

        $whatsappMessage = $this->whatsAppService->getOrderConfirmationMessage($order);
        $whatsappUrl = $this->whatsAppService->getDirectChatUrl($order->customer_phone, $whatsappMessage);

        return view('frontend.checkout_success', compact('order', 'whatsappUrl'));
    }

    public function abandonOrder(Request $request)
    {
        $request->validate([
            'order_number' => 'required|string',
            'reason' => 'nullable|string|max:255',
        ]);

        $order = Order::where('order_number', $request->order_number)->first();
        if (!$order) {
            return response()->json(['success' => false, 'message' => 'Order not found.'], 404);
        }

        // Only mark abandoned if currently pending and unpaid
        if ($order->payment_status === 'pending' && $order->order_status === 'pending') {
            $order->update([
                'order_status' => 'abandoned',
                'cancelled_reason' => $request->input('reason', 'Payment window closed by customer without completing transaction'),
            ]);

            $order->statusHistory()->create([
                'status' => 'abandoned',
                'comment' => 'Customer closed or dismissed the Razorpay payment window. Items preserved in customer cart.',
                'notify_customer' => false,
                'created_by' => 'Checkout Gateway',
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Checkout marked as abandoned. Cart remains intact.',
            ]);
        }

        return response()->json([
            'success' => true,
            'message' => 'Order status was already updated.',
        ]);
    }
}
